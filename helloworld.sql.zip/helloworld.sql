-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2018 at 07:04 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `helloworld`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank_details`
--

CREATE TABLE `bank_details` (
  `bank_id` int(11) NOT NULL,
  `bank_name` varchar(70) NOT NULL,
  `bank_branch` varchar(70) NOT NULL,
  `bank_account` varchar(16) NOT NULL,
  `bank_ifsc` varchar(20) NOT NULL,
  `fk_company` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bank_details`
--

INSERT INTO `bank_details` (`bank_id`, `bank_name`, `bank_branch`, `bank_account`, `bank_ifsc`, `fk_company`) VALUES
(1, 'Bank Of India', 'Dinbazar Branch', '4311120012003000', 'BKID43111200', 1),
(2, 'State Bank Of India', 'Jalpaiguri Branch', '1234567887654321', 'BKID876543210', 1),
(3, 'State Bank Of India', 'Ultadanga Branch', '12345655502541', 'BKID123456', 2),
(4, 'Bank Of India', 'Dinbazar', '123456789987654', '1234567896', 3),
(5, 'State Bank of India', 'Jalpaiguri', '1752615263415263', '7152465123', 3);

-- --------------------------------------------------------

--
-- Table structure for table `company_details`
--

CREATE TABLE `company_details` (
  `company_id` int(11) NOT NULL,
  `username` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  `email_ID` varchar(60) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `street` varchar(80) NOT NULL,
  `city` varchar(180) NOT NULL,
  `pincode` varchar(6) NOT NULL,
  `state` varchar(50) NOT NULL,
  `card_type` varchar(10) NOT NULL,
  `card_number` varchar(20) NOT NULL,
  `about` varchar(500) NOT NULL,
  `dated` date NOT NULL,
  `gst` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company_details`
--

INSERT INTO `company_details` (`company_id`, `username`, `password`, `email_ID`, `company_name`, `street`, `city`, `pincode`, `state`, `card_type`, `card_number`, `about`, `dated`, `gst`) VALUES
(1, 'arikSarkar', '12345678', 'arik@billosoft.com', 'BilloSoft Co. Pvt. Ltd', 'Gomastapara', 'Jalpaiguri', '735101', 'West Bengal', 'PAN', 'AWPS123456', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop p', '2018-04-21', ''),
(2, 'foodPlaza', '12345678', 'myfoods@gmail.com', 'La\'Fiesta Resturant', 'Ezra Street', 'Kolkata', '700024', 'West Bengal', 'PAN', 'AWPSK123456', 'If you\'ve ever received text that was formatted in a skinny column with line breaks at the end of each line, like text from an email or copy and pasted text from a PDF column with spacing, word wrap, or line break problems then this tool is pretty darn handy.\r\n\r\nYou also have the option of just removing all line breaks without preserving paragraph breaks (usually double line breaks).\r\n\r\nUse this tool because spending hours manually removing line breaks sucks if you\'re pasting content from someth', '2018-04-23', '123456789123125'),
(3, 'hangla', '55555555', 'hangla@gmail.com', 'Hangla Heshel', 'Gomatapara', 'Jalpaiguri', '735101', 'West Bengal', 'PAN', 'AWP12345543', 'A well-known Hotel. With delicious food.', '2018-04-28', '19AAAAAABBBBBB');

-- --------------------------------------------------------

--
-- Table structure for table `group_ledger`
--

CREATE TABLE `group_ledger` (
  `gl_id` int(11) NOT NULL,
  `exp_type` varchar(50) NOT NULL,
  `expenses_detail` varchar(100) NOT NULL,
  `cost` float NOT NULL,
  `dated` date NOT NULL,
  `fk_company` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `group_ledger`
--

INSERT INTO `group_ledger` (`gl_id`, `exp_type`, `expenses_detail`, `cost`, `dated`, `fk_company`) VALUES
(1, 'Miscellaneous', 'Electricity Bill', 1000, '2018-04-24', 2),
(2, 'Miscellaneous', 'Telephone Bill', 1500, '2018-04-24', 2);

-- --------------------------------------------------------

--
-- Table structure for table `inventory_card`
--

CREATE TABLE `inventory_card` (
  `invt_id` int(11) NOT NULL,
  `item_short_name` varchar(100) NOT NULL,
  `item_full_name` varchar(100) NOT NULL,
  `item_description` varchar(150) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `item_type` varchar(5) NOT NULL,
  `fk_company` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inventory_card`
--

INSERT INTO `inventory_card` (`invt_id`, `item_short_name`, `item_full_name`, `item_description`, `brand`, `item_type`, `fk_company`) VALUES
(943, 'Milk1', 'Milk2', 'Milk3', 'Amul', 'R', 2),
(1257, 'Roll', 'Veg', 'Aloo', 'SINGLE ALOO ROLL', 'FG', 2),
(1258, 'Roll', 'Veg', 'Aloo', 'DOUBLE ALOO ROLL', 'FG', 2),
(1259, 'Roll', 'Veg', 'Veg', 'SINGLE VEGGIE ROLL', 'FG', 2),
(1260, 'Roll', 'Veg', 'Veg', 'DOUBLE VEGGIE ROLL', 'FG', 2),
(1261, 'Roll', 'Veg', 'Paneer', 'SINGLE PANEER ROLL', 'FG', 2),
(1262, 'Roll', 'Veg', 'Paneer', 'DOUBLE PANEER ROLL', 'FG', 2),
(1263, 'Roll', 'Veg', 'Paneer', 'SINGLE PANEER BHURJI ROLL', 'FG', 2),
(1264, 'Roll', 'Veg', 'Paneer', 'DOUBLE PANEER BHURJI ROLL', 'FG', 2),
(1265, 'Roll', 'Veg', 'Mushroom', 'SINGLE MUSHROOM ROLL', 'FG', 2),
(1266, 'Roll', 'Veg', 'Mushroom', 'DOUBLE MUSHROOM ROLL', 'FG', 2),
(1267, 'Roll', 'Non Veg', 'Egg', 'SINGLE EGG ROLL', 'FG', 2),
(1268, 'Roll', 'Non Veg', 'Chicken', 'DOUBLE EGG ROLL', 'FG', 2),
(1269, 'Roll', 'Non Veg', 'Chicken', 'SINGLE CHICKEN ROLL', 'FG', 2),
(1270, 'Roll', 'Non Veg', 'Chicken', 'DOUBLE CHICKEN ROLL', 'FG', 2),
(1271, 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG SINGLE CHICKEN ROLL', 'FG', 2),
(1272, 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG DOUBLE CHICKEN ROLL', 'FG', 2),
(1273, 'Roll', 'Non Veg', 'Chicken', 'DOUBLE EGG DOUBLE CHICKEN ROLL', 'FG', 2),
(1274, 'Roll', 'Non Veg', 'Mutton', 'SINGLE MUTTON ROLL', 'FG', 2),
(1275, 'Roll', 'Non Veg', 'Mutton', 'DOUBLE MUTTON ROLL', 'FG', 2),
(1276, 'Roll', 'Non Veg', 'Mutton', 'SINGLE EGG SINGLE MUTTON ROLL', 'FG', 2),
(1277, 'Roll', 'Non Veg', 'Mutton', 'SINGLE EGG DOUBLE MUTTON ROLL', 'FG', 2),
(1278, 'Roll', 'Non Veg', 'Mutton', 'DOUBLE EGG DOUBLE MUTTON ROLL', 'FG', 2),
(1279, 'Roll', 'Non Veg', 'Chicken', 'SINGLE CHICKEN TIKKA ROLL', 'FG', 2),
(1280, 'Roll', 'Non Veg', 'Chicken', 'DOUBLE CHICKEN TIKKA ROLL', 'FG', 2),
(1281, 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG SINGLE CHICKEN TIKKA ROLL', 'FG', 2),
(1282, 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG DOUBLE CHICKEN TIKKA ROLL', 'FG', 2),
(1283, 'Roll', 'Non Veg', 'Chicken', 'DOUBLE EGG DOUBLE CHICKEN TIKKA ROLL', 'FG', 2),
(1284, 'Roll', 'Non Veg', 'Chicken', 'SINGLE CHICKEN-SEEKH ROLL', 'FG', 2),
(1285, 'Roll', 'Non Veg', 'Chicken', 'DOUBLE CHICKEN-SEEKH ROLL', 'FG', 2),
(1286, 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG SINGLE CHICKEN-SEEKH ROLL', 'FG', 2),
(1287, 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG DOUBLE CHICKEN-SEEKH ROLL', 'FG', 2),
(1288, 'Roll', 'Non Veg', 'Chicken', 'DOUBLE EGG DOUBLE CHICKEN-SEEKH ROLL', 'FG', 2),
(1289, 'Roll', 'Non Veg', 'Mutton', 'SINGLE MUTTON-SEEKH ROLL', 'FG', 2),
(1290, 'Roll', 'Non Veg', 'Mutton', 'DOUBLE MUTTON-SEEKH ROLL', 'FG', 2),
(1291, 'Roll', 'Non Veg', 'Mutton', 'SINGLE EGG SINGLE MUTTON-SEEKH ROLL', 'FG', 2),
(1292, 'Roll', 'Non Veg', 'Chicken', 'CHICKEN RUMALI ROLL', 'FG', 2),
(1293, 'Roll', 'Non Veg', 'Chicken', 'CHICKEN TIKKA RUMALI ROLL', 'FG', 2),
(1294, 'Roll', 'Non Veg', 'Mutton', 'MUTTON RUMALI ROLL', 'FG', 2),
(1295, 'Roll', 'Non Veg', 'Chicken', 'CHICKEN-SEEKH RUMALI ROLL', 'FG', 2),
(1296, 'Roll', 'Non Veg', 'Chicken', 'DOUBLE CHICKEN SEEKH RUMALI ROLL', 'FG', 2),
(1297, 'Roll', 'Non Veg', 'Mutton', 'MUTTON-SEEKH RUMALI ROLL', 'FG', 2),
(1298, 'Roll', 'Non Veg', 'Mutton', 'DOUBLE MUTTON SEEKH RUMALI ROLL', 'FG', 2),
(1299, 'Roll', 'Non Veg', 'Chicken', 'SINGLE SHAWARMA', 'FG', 2),
(1300, 'Roll', 'Non Veg', 'Chicken', 'DOUBLE SHAWARMA', 'FG', 2),
(1301, 'Chinese', 'Veg', 'Veg', 'VEG STEAMED', 'FG', 2),
(1302, 'Chinese', 'Veg', 'Veg', 'VEG FRIED', 'FG', 2),
(1303, 'Chinese', 'Veg', 'Veg', 'VEG PAN FRIED', 'FG', 2),
(1304, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN STEAMED', 'FG', 2),
(1305, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN FRIED', 'FG', 2),
(1306, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN PAN FRIED', 'FG', 2),
(1307, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN SCHEZWAN ', 'FG', 2),
(1308, 'Chinese', 'Veg', 'Veg', 'VEG THAI SOUP', 'FG', 2),
(1309, 'Chinese', 'Veg', 'Veg', 'VEG SWEET CORN SOUP', 'FG', 2),
(1310, 'Chinese', 'Veg', 'Veg', 'VEG HOT N SOUR SOUP', 'FG', 2),
(1311, 'Chinese', 'Veg', 'Veg', 'VEG LEMON CORIANDER', 'FG', 2),
(1312, 'Chinese', 'Veg', 'Veg', 'VEG MANCHOW SOUP', 'FG', 2),
(1313, 'Chinese', 'Non Veg', 'Egg', 'EGG SWEET CORN SOUP', 'FG', 2),
(1314, 'Chinese', 'Non Veg', 'Egg', 'EGG HOT N SOUR SOUP', 'FG', 2),
(1315, 'Chinese', 'Non Veg', 'Egg', 'EGG LEMON CORIANDER', 'FG', 2),
(1316, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN CLEAR SOUP', 'FG', 2),
(1317, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN SWEET CORN SOUP', 'FG', 2),
(1318, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN HOT N SOUR SOUP', 'FG', 2),
(1319, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN THAI SOUP', 'FG', 2),
(1320, 'Chinese', 'Non Veg', 'Chicken', 'LUNG FUNG SOUP', 'FG', 2),
(1321, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN LEMON CORIANDER', 'FG', 2),
(1322, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN MANCHOW SOUP', 'FG', 2),
(1323, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN MUSHROOM SOUP', 'FG', 2),
(1324, 'Chinese', 'Veg', 'Potato', 'CRISPY CHILLI POTATO', 'FG', 2),
(1325, 'Chinese', 'Veg', 'Baby Corn', 'FRIED BABY CORN', 'FG', 2),
(1326, 'Chinese', 'Veg', 'Baby Corn', 'CHILLI GARLIC BABY CORN', 'FG', 2),
(1327, 'Chinese', 'Veg', 'Corn', 'AMERICAN CORN', 'FG', 2),
(1328, 'Chinese', 'Veg', 'Mushroom', 'CHILLI GARLIC BUTTON MUSHROOM', 'FG', 2),
(1329, 'Chinese', 'Veg', 'Mushroom', 'PEPPER MUSHROOM', 'FG', 2),
(1330, 'Chinese', 'Veg', 'Paneer', 'PANEER PAKORA (6 PCS)', 'FG', 2),
(1331, 'Chinese', 'Non Veg', 'Fish', 'FISH PAKORA (6 PCS)', 'FG', 2),
(1332, 'Chinese', 'Non Veg', 'Fish', 'PEPPER CHILLI GARLIC FISH (6 PCS)', 'FG', 2),
(1333, 'Chinese', 'Non Veg', 'Fish', 'FISH FINGER (6 PCS)', 'FG', 2),
(1334, 'Chinese', 'Non Veg', 'Fish', 'CRISPY FISH (6 PCS)', 'FG', 2),
(1335, 'Chinese', 'Non Veg', 'Fish', 'PAN FRIED CHILLI FISH (6 PCS)', 'FG', 2),
(1336, 'Chinese', 'Non Veg', 'Chicken', 'FRIED CHICKEN (6 PCS)', 'FG', 2),
(1337, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN PAKORA (6 PCS)', 'FG', 2),
(1338, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN LOLLYPOP', 'FG', 2),
(1339, 'Chinese', 'Non Veg', 'Chicken', 'DRUMS OF HEAVEN (6 PCS)', 'FG', 2),
(1340, 'Chinese', 'Non Veg', 'Chicken', 'CHILLI GARLIC DRUMS OF HEAVEN (6 PCS)', 'FG', 2),
(1341, 'Chinese', 'Non Veg', 'Chicken', 'CHILLI GARLIC PEPPER CHICKEN (6 PCS)', 'FG', 2),
(1342, 'Chinese', 'Non Veg', 'Chicken', 'PEPPER CHICKEN (6 PCS)', 'FG', 2),
(1343, 'Chinese', 'Non Veg', 'Chicken', 'CRISPY CHICKEN (6 PCS)', 'FG', 2),
(1344, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN 65 (6 PCS)', 'FG', 2),
(1345, 'Chinese', 'Non Veg', 'Chicken', 'PAN FRIED CHILLI CHICKEN (6 PCS)', 'FG', 2),
(1346, 'Chinese', 'Non Veg', 'Chicken', 'CRISPY HONEY CHILLI CHICKEN (6 PCS)', 'FG', 2),
(1347, 'Chinese', 'Non Veg', 'Prawn', 'PRAWN PAKORA (6 PCS)', 'FG', 2),
(1348, 'Chinese', 'Non Veg', 'Prawn', 'CRISPY PRAWN (6 PCS)', 'FG', 2),
(1349, 'Chinese', 'Non Veg', 'Prawn', 'CHILLI GARLIC PRAWN (6 PCS)', 'FG', 2),
(1350, 'Tandoor', 'Veg', 'Paneer', 'PANEER TIKKA (6 PCS)', 'FG', 2),
(1351, 'Tandoor', 'Veg', 'Paneer', 'PANEER MALAI TIKKA (6 PCS)', 'FG', 2),
(1352, 'Tandoor', 'Veg', 'Paneer', 'PANEER SASHLIK (6 PCS)', 'FG', 2),
(1353, 'Tandoor', 'Veg', 'Mushroom', 'MUSHROOM TIKKA (6 PCS)', 'FG', 2),
(1354, 'Tandoor', 'Non Veg', 'Fish', 'FISH TIKKA (4 PCS)', 'FG', 2),
(1355, 'Tandoor', 'Non Veg', 'Fish', 'FISH IRANI KEBAB (4 PCS)', 'FG', 2),
(1356, 'Tandoor', 'Non Veg', 'Fish', 'FISH MAKHMALI KEBAB (4 PCS)', 'FG', 2),
(1357, 'Tandoor', 'Non Veg', 'Mutton', 'MUTTON BOTI KEBAB (6 PCS)', 'FG', 2),
(1358, 'Tandoor', 'Non Veg', 'Mutton', 'MUTTON TIKKA (6 PCS)', 'FG', 2),
(1359, 'Tandoor', 'Non Veg', 'Mutton', 'MUTTON SEEKH KEBAB (6 PCS)', 'FG', 2),
(1360, 'Tandoor', 'Non Veg', 'Chicken', 'MURGH TIKKA (6 PCS)', 'FG', 2),
(1361, 'Tandoor', 'Non Veg', 'Chicken', 'MURGH RESHMI KEBAB (6 PCS)', 'FG', 2),
(1362, 'Tandoor', 'Non Veg', 'Chicken', 'MURGH SEEKH KEBAB (6 PCS)', 'FG', 2),
(1363, 'Tandoor', 'Non Veg', 'Chicken', 'MURGH HARIYALI KEBAB (6 PCS)', 'FG', 2),
(1364, 'Tandoor', 'Non Veg', 'Chicken', 'MURGH LASOONI KEBAB (6 PCS)', 'FG', 2),
(1365, 'Tandoor', 'Non Veg', 'Chicken', 'MURGH KASTURI KEBAB (6 PCS)', 'FG', 2),
(1366, 'Tandoor', 'Non Veg', 'Chicken', 'MURGH MALAI KEBAB (6 PCS)', 'FG', 2),
(1367, 'Tandoor', 'Non Veg', 'Chicken', 'MURGH CHEESE KEBAB (6 PCS)', 'FG', 2),
(1368, 'Tandoor', 'Non Veg', 'Chicken', 'MURGH IRANI ', 'FG', 2),
(1369, 'Tandoor', 'Non Veg', 'Chicken', 'MURGH TANGRI KEBAB', 'FG', 2),
(1370, 'Tandoor', 'Non Veg', 'Chicken', 'MURGH AFGHANI TANGRI', 'FG', 2),
(1371, 'Tandoor', 'Non Veg', 'Chicken', 'TANDOORI MURGH HALF', 'FG', 2),
(1372, 'Tandoor', 'Non Veg', 'Chicken', 'TANDOORI MURGH FULL', 'FG', 2),
(1373, 'Tandoor', 'Non Veg', 'Chicken', 'MURGH AFGHANI TANDOORI HALF', 'FG', 2),
(1374, 'Tandoor', 'Non Veg', 'Chicken', 'MURGH AFGHANI TANDOORI FULL', 'FG', 2),
(1375, 'Tandoor', 'Non Veg', 'Chicken', 'MURGH PLATTER (9 KEBABS AND 1 TAGRI)', 'FG', 2),
(1376, 'Chinese', 'Veg', 'Veg', 'VEG FRIED RICE', 'FG', 2),
(1377, 'Chinese', 'Non Veg', 'Egg', 'EGG FRIED RICE', 'FG', 2),
(1378, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN FRIED RICE', 'FG', 2),
(1379, 'Chinese', 'Non Veg', 'Prawn', 'PRAWN FRIED RICE', 'FG', 2),
(1380, 'Chinese', 'Non Veg', 'Mixed', 'MIXED FRIED RICE', 'FG', 2),
(1381, 'Chinese', 'Veg', 'Veg', 'VEG SCHEZWAN FRIED RICE', 'FG', 2),
(1382, 'Chinese', 'Non Veg', 'Egg', 'EGG SCHEZWAN FRIED RICE', 'FG', 2),
(1383, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN SCHEZWAN FRIED RICE', 'FG', 2),
(1384, 'Chinese', 'Non Veg', 'Prawn', 'PRAWN SCHEZWAN FRIED RICE', 'FG', 2),
(1385, 'Chinese', 'Non Veg', 'Mixed', 'MIXED SCHEZWAN FRIED RICE', 'FG', 2),
(1386, 'Chinese', 'Veg', 'Veg', 'VEG CHILLI GARLIC FRIED RICE', 'FG', 2),
(1387, 'Chinese', 'Non Veg', 'Egg', 'EGG CHILLI GARLIC FRIED RICE', 'FG', 2),
(1388, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN CHILLI GARLIC FRIED RICE', 'FG', 2),
(1389, 'Chinese', 'Non Veg', 'Prawn', 'PRAWN CHILLI GARLIC FRIED RICE', 'FG', 2),
(1390, 'Chinese', 'Non Veg', 'Mixed', 'MIXED CHILLI GARLIC FRIED RICE', 'FG', 2),
(1391, 'Chinese', 'Veg', 'Veg', 'VEG CANTONESE FRIED RICE', 'FG', 2),
(1392, 'Chinese', 'Non Veg', 'Egg', 'EGG CANTONESE FRIED RICE', 'FG', 2),
(1393, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN CANTONESE FRIED RICE', 'FG', 2),
(1394, 'Chinese', 'Non Veg', 'Prawn', 'PRAWN CANTONESE FRIED RICE', 'FG', 2),
(1395, 'Chinese', 'Non Veg', 'Mixed', 'MIXED CANTONESE FRIED RICE', 'FG', 2),
(1396, 'Chinese', 'Veg', 'Veg', 'VEG BUTTER GARLIC FRIED RICE', 'FG', 2),
(1397, 'Chinese', 'Non Veg', 'Egg', 'EGG BUTTER GARLIC FRIED RICE', 'FG', 2),
(1398, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN BUTTER GARLIC FRIED RICE', 'FG', 2),
(1399, 'Chinese', 'Non Veg', 'Prawn', 'PRAWN BUTTER GARLIC FRIED RICE', 'FG', 2),
(1400, 'Chinese', 'Non Veg', 'Mixed', 'MIXED BUTTER GARLIC FRIED RICE', 'FG', 2),
(1401, 'Chinese', 'Veg', 'Veg', 'VEG HAKKA NOODLES', 'FG', 2),
(1402, 'Chinese', 'Non Veg', 'Egg', 'EGG HAKKA NOODLES', 'FG', 2),
(1403, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN HAKKA NOODLES', 'FG', 2),
(1404, 'Chinese', 'Non Veg', 'Prawn', 'PRAWN HAKKA NOODLES', 'FG', 2),
(1405, 'Chinese', 'Non Veg', 'Mixed', 'MIXED HAKKA NOODLES', 'FG', 2),
(1406, 'Chinese', 'Veg', 'Veg', 'VEG SCHEZWAN HAKKA NOODLES', 'FG', 2),
(1407, 'Chinese', 'Non Veg', 'Egg', 'EGG SCHEZWAN HAKKA NOODLES', 'FG', 2),
(1408, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN SCHEZWAN HAKKA NOODLES', 'FG', 2),
(1409, 'Chinese', 'Non Veg', 'Prawn', 'PRAWN SCHEZWAN HAKKA NOODLES', 'FG', 2),
(1410, 'Chinese', 'Non Veg', 'Mixed', 'MIXED SCHEZWAN HAKKA NOODLES', 'FG', 2),
(1411, 'Chinese', 'Veg', 'Veg', 'VEG CHILLI GARLIC HAKKA NOODLES', 'FG', 2),
(1412, 'Chinese', 'Non Veg', 'Egg', 'EGG CHILLI GARLIC HAKKA NOODLES', 'FG', 2),
(1413, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN CHILLI GARLIC HAKKA NOODLES', 'FG', 2),
(1414, 'Chinese', 'Non Veg', 'Prawn', 'PRAWN CHILLI GARLIC HAKKA NOODLES', 'FG', 2),
(1415, 'Chinese', 'Non Veg', 'Mixed', 'MIXED CHILLI GARLIC HAKKA NOODLES', 'FG', 2),
(1416, 'Chinese', 'Veg', 'Veg', 'VEG CANTONESE GRAVY NOODLES', 'FG', 2),
(1417, 'Chinese', 'Non Veg', 'Egg', 'EGG CANTONESE GRAVY NOODLES', 'FG', 2),
(1418, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN CANTONESE GRAVY NOODLES', 'FG', 2),
(1419, 'Chinese', 'Non Veg', 'Prawn', 'PRAWN CANTONESE GRAVY NOODLES', 'FG', 2),
(1420, 'Chinese', 'Non Veg', 'Mixed', 'MIXED CANTONESE GRAVY NOODLES', 'FG', 2),
(1421, 'Chinese', 'Veg', 'Veg', 'VEG GRAVY NOODLES', 'FG', 2),
(1422, 'Chinese', 'Non Veg', 'Egg', 'EGG GRAVY NOODLES', 'FG', 2),
(1423, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN GRAVY NOODLES', 'FG', 2),
(1424, 'Chinese', 'Non Veg', 'Mixed', 'MIXED GRAVY NOODLES', 'FG', 2),
(1425, 'Chinese', 'Non Veg', 'Mixed', 'AMERICAN CHOPSUEY', 'FG', 2),
(1426, 'Chinese', 'Veg', 'Paneer', 'CHILLI PANEER (6 PCS)', 'FG', 2),
(1427, 'Chinese', 'Veg', 'Paneer', 'GARLIC PANEER (6 PCS)', 'FG', 2),
(1428, 'Chinese', 'Veg', 'Paneer', 'PANEER MANCHURIAN (6 PCS)', 'FG', 2),
(1429, 'Chinese', 'Veg', 'Paneer', 'SCHEZWAN PANEER (6 PCS)', 'FG', 2),
(1430, 'Chinese', 'Veg', 'Paneer', 'PANEER SWEET N SOUR (6 PCS)', 'FG', 2),
(1431, 'Chinese', 'Veg', 'Corn', 'CHILLI BABY CORN ', 'FG', 2),
(1432, 'Chinese', 'Veg', 'Corn', 'GARLIC BABY CORN ', 'FG', 2),
(1433, 'Chinese', 'Veg', 'Corn', 'CHILLI GARLIC BABY CORN ', 'FG', 2),
(1434, 'Chinese', 'Veg', 'Corn', 'BABY CORN MANCHURIAN', 'FG', 2),
(1435, 'Chinese', 'Veg', 'Corn', 'SCHEZWAN BABY CORN ', 'FG', 2),
(1436, 'Chinese', 'Veg', 'Corn', 'LEMON BABY CORN ', 'FG', 2),
(1437, 'Chinese', 'Veg', 'Mushroom', 'CHILLI MUSHROOM ', 'FG', 2),
(1438, 'Chinese', 'Veg', 'Mushroom', 'GARLIC MUSHROOM ', 'FG', 2),
(1439, 'Chinese', 'Veg', 'Mushroom', 'CHILLI GARLIC MUSHROOM ', 'FG', 2),
(1440, 'Chinese', 'Veg', 'Mushroom', 'MUSHROOM MANCHURIAN', 'FG', 2),
(1441, 'Chinese', 'Veg', 'Mushroom', 'SCHEZWAN MUSHROOM ', 'FG', 2),
(1442, 'Chinese', 'Veg', 'Mushroom', 'LEMON MUSHROOM ', 'FG', 2),
(1443, 'Chinese', 'Non Veg', 'Chicken', 'CHILLI CHICKEN (6 PCS)', 'FG', 2),
(1444, 'Chinese', 'Non Veg', 'Chicken', 'GARLIC CHICKEN (6 PCS)', 'FG', 2),
(1445, 'Chinese', 'Non Veg', 'Chicken', 'CHILLI GARLIC CHICKEN (6 PCS)', 'FG', 2),
(1446, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN MANCHURIAN (6 PCS)', 'FG', 2),
(1447, 'Chinese', 'Non Veg', 'Chicken', 'SCHEZWAN CHICKEN (6 PCS)', 'FG', 2),
(1448, 'Chinese', 'Non Veg', 'Chicken', 'LEMON CHICKEN (6 PCS)', 'FG', 2),
(1449, 'Chinese', 'Non Veg', 'Chicken', 'HUNAN CHICKEN (6 PCS)', 'FG', 2),
(1450, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN SWEET N SOUR (6 PCS)', 'FG', 2),
(1451, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN 65 (6 PCS)', 'FG', 2),
(1452, 'Chinese', 'Non Veg', 'Chicken', 'CHILLI LEMON CHICKEN (6 PCS)', 'FG', 2),
(1453, 'Chinese', 'Non Veg', 'Chicken', 'KUNG PAO CHICKEN (6 PCS)', 'FG', 2),
(1454, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN IN BLACK BEAN SAUCE (6 PCS)', 'FG', 2),
(1455, 'Chinese', 'Non Veg', 'Fish', 'CHILLI FISH (6 PCS)', 'FG', 2),
(1456, 'Chinese', 'Non Veg', 'Fish', 'GARLIC FISH (6 PCS)', 'FG', 2),
(1457, 'Chinese', 'Non Veg', 'Fish', 'CHILLI GARLIC FISH (6 PCS)', 'FG', 2),
(1458, 'Chinese', 'Non Veg', 'Fish', 'FISH MANCHURIAN(6 PCS)', 'FG', 2),
(1459, 'Chinese', 'Non Veg', 'Fish', 'SCHEZWAN FISH (6 PCS)', 'FG', 2),
(1460, 'Chinese', 'Non Veg', 'Fish', 'LEMON FISH (6 PCS)', 'FG', 2),
(1461, 'Chinese', 'Non Veg', 'Fish', 'HUNAN FISH (6 PCS)', 'FG', 2),
(1462, 'Chinese', 'Non Veg', 'Fish', 'FISH SWEET N SOUR (6 PCS)', 'FG', 2),
(1463, 'Chinese', 'Non Veg', 'Fish', 'FISH 65 (6 PCS)', 'FG', 2),
(1464, 'Chinese', 'Non Veg', 'Fish', 'FISH IN MUSTARD SAUCE (6 PCS)', 'FG', 2),
(1465, 'Chinese', 'Non Veg', 'Fish', 'CHILLI LEMON FISH (6 PCS)', 'FG', 2),
(1466, 'Chinese', 'Non Veg', 'Fish', 'KUNG PAO FISH (6 PCS)', 'FG', 2),
(1467, 'Chinese', 'Non Veg', 'Prawn', 'CHILLI PRAWN (6 PCS)', 'FG', 2),
(1468, 'Chinese', 'Non Veg', 'Prawn', 'GARLIC PRAWN (6 PCS)', 'FG', 2),
(1469, 'Chinese', 'Non Veg', 'Prawn', 'CHILLI GARLIC PRAWN (6 PCS)', 'FG', 2),
(1470, 'Chinese', 'Non Veg', 'Prawn', 'PRAWN MANCHURIAN (6 PCS)', 'FG', 2),
(1471, 'Chinese', 'Non Veg', 'Prawn', 'SCHEZWAN PRAWN (6 PCS)', 'FG', 2),
(1472, 'Chinese', 'Non Veg', 'Prawn', 'LEMON PRAWN (6 PCS)', 'FG', 2),
(1473, 'Chinese', 'Non Veg', 'Prawn', 'HUNAN PRAWN (6 PCS)', 'FG', 2),
(1474, 'Chinese', 'Non Veg', 'Prawn', 'PRAWN SWEET N SOUR (6 PCS)', 'FG', 2),
(1475, 'Chinese', 'Non Veg', 'Prawn', 'PRAWN 65 (6 PCS)', 'FG', 2),
(1476, 'Chinese', 'Non Veg', 'Prawn', 'CHILLI LEMON PRAWN (6 PCS)', 'FG', 2),
(1477, 'Chinese', 'Non Veg', 'Prawn', 'KUNG PAO PRAWN (6 PCS)', 'FG', 2),
(1478, 'Indian', 'Veg', 'Veg', 'STEAMED RICE', 'FG', 2),
(1479, 'Indian', 'Veg', 'Veg', 'JEERA RICE', 'FG', 2),
(1480, 'Indian', 'Veg', 'Veg', 'VEG PULAO', 'FG', 2),
(1481, 'Indian', 'Veg', 'Veg', 'KASHMIRI PULAO', 'FG', 2),
(1482, 'Indian', 'Non Veg', 'Chicken', 'CHICKEN BIRIYANI', 'FG', 2),
(1483, 'Indian', 'Non Veg', 'Mutton', 'MUTTON BIRIYANI', 'FG', 2),
(1484, 'Indian', 'Veg', 'Roti', 'RUMALI ROTI', 'FG', 2),
(1485, 'Indian', 'Veg', 'Roti', 'TANDOORI ROTI', 'FG', 2),
(1486, 'Indian', 'Veg', 'Roti', 'BUTTER TANDOORI ROTI', 'FG', 2),
(1487, 'Indian', 'Veg', 'Naan', 'PLAIN NAAN', 'FG', 2),
(1488, 'Indian', 'Veg', 'Naan', 'BUTTER NAAN', 'FG', 2),
(1489, 'Indian', 'Veg', 'Lachha', 'LACHHA PARATHA', 'FG', 2),
(1490, 'Indian', 'Veg', 'Kulcha', 'KULCHA ', 'FG', 2),
(1491, 'Indian', 'Veg', 'Kulcha', 'MASALA KULCHA', 'FG', 2),
(1492, 'Indian', 'Veg', 'Dal', 'DAL FRY', 'FG', 2),
(1493, 'Indian', 'Veg', 'Dal', 'DAL MAKHANI', 'FG', 2),
(1494, 'Indian', 'Veg', 'Aloo', 'ALOO MUTTER', 'FG', 2),
(1495, 'Indian', 'Veg', 'Aloo', 'JEERA ALOO', 'FG', 2),
(1496, 'Indian', 'Veg', 'Aloo', 'DUM ALOO', 'FG', 2),
(1497, 'Indian', 'Veg', 'Dal', 'VEG TADKA ', 'FG', 2),
(1498, 'Indian', 'Veg', 'Veg', 'VEG SHAHI KOFTA', 'FG', 2),
(1499, 'Indian', 'Veg', 'Veg', 'NAVRATAN KORMA', 'FG', 2),
(1500, 'Indian', 'Veg', 'Paneer', 'MUTTER PANEER', 'FG', 2),
(1501, 'Indian', 'Veg', 'Paneer', 'PANEER MASALA', 'FG', 2),
(1502, 'Indian', 'Veg', 'Paneer', 'PANEER BUTTER MASALA', 'FG', 2),
(1503, 'Indian', 'Veg', 'Paneer', 'KADHAI PANEER', 'FG', 2),
(1504, 'Indian', 'Veg', 'Paneer', 'HANDI PANEER', 'FG', 2),
(1505, 'Indian', 'Veg', 'Paneer', 'PANEER KOFTA', 'FG', 2),
(1506, 'Indian', 'Veg', 'Paneer', 'PANEER MALAI KOFTA', 'FG', 2),
(1507, 'Indian', 'Non Veg', 'Dal', 'EGG TADKA ', 'FG', 2),
(1508, 'Indian', 'Veg', 'Dal', 'PANEER TADKA ', 'FG', 2),
(1509, 'Indian', 'Non Veg', 'Dal', 'CHICKEN TADKA ', 'FG', 2),
(1510, 'Indian', 'Non Veg', 'Dal', 'MUTTON KEEMA TADKA ', 'FG', 2),
(1511, 'Indian', 'Non Veg', 'Chicken', 'CHICKEN CHAAP', 'FG', 2),
(1512, 'Indian', 'Non Veg', 'Chicken', 'CHICKEN CURRY (4 PCS)', 'FG', 2),
(1513, 'Indian', 'Non Veg', 'Chicken', 'CHICKEN KASSA (4 PCS)', 'FG', 2),
(1514, 'Indian', 'Non Veg', 'Chicken', 'CHICKEN KORMA (4 PCS)', 'FG', 2),
(1515, 'Indian', 'Non Veg', 'Chicken', 'CHICKEN MASALA (4 PCS)', 'FG', 2),
(1516, 'Indian', 'Non Veg', 'Chicken', 'CHICKEN DOPiYAZA (4 PCS)', 'FG', 2),
(1517, 'Indian', 'Non Veg', 'Chicken', 'CHICKEN BHARTA', 'FG', 2),
(1518, 'Indian', 'Non Veg', 'Chicken', 'CHICKEN REZALA (4 PCS)', 'FG', 2),
(1519, 'Indian', 'Non Veg', 'Chicken', 'HANDI CHICKEN (4 PCS)', 'FG', 2),
(1520, 'Indian', 'Non Veg', 'Chicken', 'KADHAI CHICKEN (4 PCS)', 'FG', 2),
(1521, 'Indian', 'Non Veg', 'Chicken', 'TAWA CHICKEN (4 PCS)', 'FG', 2),
(1522, 'Indian', 'Non Veg', 'Chicken', 'CHICKEN BEGUM BAHAR (4 PCS)', 'FG', 2),
(1523, 'Indian', 'Non Veg', 'Chicken', 'CHICKEN TIKKA BUTTER MASALA (6 PCS)', 'FG', 2),
(1524, 'Indian', 'Non Veg', 'Chicken', 'CHICKEN TANGRI BUTTER MASALA (2 PCS)', 'FG', 2),
(1525, 'Indian', 'Non Veg', 'Chicken', 'CHICKEN TANDOORI BUTTER MASALA (2 PCS)', 'FG', 2),
(1526, 'Indian', 'Non Veg', 'Chicken', 'CHICKEN RESHMI BUTTER MASALA (6 PCS)', 'FG', 2),
(1527, 'Indian', 'Non Veg', 'Chicken', 'CHICKEN HARIYALI BUTTER MASALA (6 PCS)', 'FG', 2),
(1528, 'Indian', 'Non Veg', 'Fish', 'FISH MASALA (4 PCS)', 'FG', 2),
(1529, 'Indian', 'Non Veg', 'Fish', 'FISH TIKKA BUTTER MASALA (4 PCS)', 'FG', 2),
(1530, 'Indian', 'Non Veg', 'Fish', 'FISH RESHMI BUTTER MASALA (4 PCS)', 'FG', 2),
(1531, 'Indian', 'Non Veg', 'Fish', 'FISH BEGUM BAHAR (4 PCS)', 'FG', 2),
(1532, 'Indian', 'Non Veg', 'Prawn', 'PRAWN MASALA', 'FG', 2),
(1533, 'Indian', 'Non Veg', 'Prawn', 'PRAWN BUTTER MASALA', 'FG', 2),
(1534, 'Indian', 'Non Veg', 'Prawn', 'PRAWN MALAI CURRY', 'FG', 2),
(1535, 'Indian', 'Non Veg', 'Prawn', 'PRAWN BUTTER MASALA', 'FG', 2),
(1536, 'Indian', 'Non Veg', 'Mutton', 'MUTTON CURRY (4 PCS)', 'FG', 2),
(1537, 'Indian', 'Non Veg', 'Mutton', 'MUTTON KASSA (4 PCS)', 'FG', 2),
(1538, 'Indian', 'Non Veg', 'Mutton', 'MUTTON DOPYAZA (4 PCS)', 'FG', 2),
(1539, 'Indian', 'Non Veg', 'Mutton', 'MUTTON KORMA (4 PCS)', 'FG', 2),
(1540, 'Indian', 'Non Veg', 'Mutton', 'MUTTON CHAAP (4 PCS)', 'FG', 2),
(1541, 'Indian', 'Non Veg', 'Mutton', 'MUTTON MASALA (4 PCS)', 'FG', 2),
(1542, 'Indian', 'Non Veg', 'Mutton', 'MUTTON KEEMA MASALA', 'FG', 2),
(1543, 'Indian', 'Non Veg', 'Mutton', 'MUTTON REZALA (4 PCS)', 'FG', 2),
(1544, 'Indian', 'Non Veg', 'Mutton', 'TAWA MUTTON (4 PCS)', 'FG', 2),
(1545, 'Indian', 'Non Veg', 'Mutton', 'HANDI MUTTON (4 PCS)', 'FG', 2),
(1546, 'Indian', 'Non Veg', 'Mutton', 'KADHAI MUTTON (4 PCS)', 'FG', 2),
(1547, 'Indian', 'Non Veg', 'Mutton', 'MUTTON BEGUM BAHAR (4 PCS)', 'FG', 2),
(1548, 'Indian', 'Veg', 'Veg', 'GREEN SALAD', 'FG', 2),
(1549, 'Indian', 'Veg', 'Veg', 'ONION SALAD', 'FG', 2),
(1550, 'Chinese', 'Non Veg', 'Chicken', 'CHICKEN SALAD', 'FG', 2),
(1551, 'Beverages', 'Beverages', 'Water', 'MINERAL WATER', 'FG', 2),
(1552, 'Beverages', 'Beverages', 'Cold Drinks', 'THUMS UP', 'FG', 2),
(1553, 'Beverages', 'Beverages', 'Cold Drinks', 'LIMCA', 'FG', 2),
(1554, 'Beverages', 'Beverages', 'Cold Drinks', 'FANTA', 'FG', 2),
(1555, 'Beverages', 'Beverages', 'Cold Drinks', 'MASALA COLD DRINKS', 'FG', 2),
(1556, 'Beverages', 'Beverages', 'Soda', 'FRESH LIME SODA', 'FG', 2),
(1557, 'Beverages', 'Beverages', 'Soda', 'SWEET LIME SODA', 'FG', 2),
(1558, 'Beverages', 'Beverages', 'Soda', 'MASALA SODA', 'FG', 2),
(1559, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'STRAWBERRY', 'FG', 2),
(1560, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'VANILLA', 'FG', 2),
(1561, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'TWO IN ONE', 'FG', 2),
(1562, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'CHOCOLATE', 'FG', 2),
(1563, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'BUTTER SCOTCH', 'FG', 2),
(1564, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'MANGO', 'FG', 2),
(1565, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'MANGO MASTANI', 'FG', 2),
(1566, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'DREAMY RAINBOW', 'FG', 2),
(1567, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'CHOCOLATE OVERLOAD', 'FG', 2),
(1568, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'CRUNCHY OREO MAGIC', 'FG', 2);

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `invoice_id` int(11) NOT NULL,
  `fk_invt_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `weight_per_qty` varchar(10) NOT NULL,
  `net_weight` varchar(15) NOT NULL,
  `wt_unit` varchar(5) NOT NULL,
  `price` float NOT NULL,
  `final_amount` float NOT NULL,
  `fk_purchase_id` int(11) NOT NULL,
  `fk_company` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `in_hand`
--

CREATE TABLE `in_hand` (
  `in_hand_id` int(11) NOT NULL,
  `fk_inv_id` int(11) NOT NULL,
  `resultant_quantity` varchar(10) NOT NULL,
  `fk_company` int(11) NOT NULL,
  `unit` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `logo`
--

CREATE TABLE `logo` (
  `logo_id` int(11) NOT NULL,
  `logo_file_name` varchar(500) NOT NULL,
  `fk_company` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logo`
--

INSERT INTO `logo` (`logo_id`, `logo_file_name`, `fk_company`) VALUES
(1, 'logo-ex-7.png', 1),
(2, 'logo-ex-4.png', 2),
(3, 'hangla.png', 3);

-- --------------------------------------------------------

--
-- Table structure for table `menu_card`
--

CREATE TABLE `menu_card` (
  `menu_id` int(11) NOT NULL,
  `level_1` varchar(100) NOT NULL,
  `level_2` varchar(120) NOT NULL,
  `level_3` varchar(150) NOT NULL,
  `level_4` varchar(150) NOT NULL,
  `level_5` varchar(200) NOT NULL,
  `price` float NOT NULL,
  `fk_company` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu_card`
--

INSERT INTO `menu_card` (`menu_id`, `level_1`, `level_2`, `level_3`, `level_4`, `level_5`, `price`, `fk_company`) VALUES
(1, 'Roll', 'Roll', 'Veg', 'Aloo', 'SINGLE ALOO ROLL', 30, 2),
(2, 'Roll', 'Roll', 'Veg', 'Aloo', 'DOUBLE ALOO ROLL', 45, 2),
(3, 'Roll', 'Roll', 'Veg', 'Veg', 'SINGLE VEGGIE ROLL', 40, 2),
(4, 'Roll', 'Roll', 'Veg', 'Veg', 'DOUBLE VEGGIE ROLL', 50, 2),
(5, 'Roll', 'Roll', 'Veg', 'Paneer', 'SINGLE PANEER ROLL', 50, 2),
(6, 'Roll', 'Roll', 'Veg', 'Paneer', 'DOUBLE PANEER ROLL', 70, 2),
(7, 'Roll', 'Roll', 'Veg', 'Paneer', 'SINGLE PANEER BHURJI ROLL', 50, 2),
(8, 'Roll', 'Roll', 'Veg', 'Paneer', 'DOUBLE PANEER BHURJI ROLL', 70, 2),
(9, 'Roll', 'Roll', 'Veg', 'Mushroom', 'SINGLE MUSHROOM ROLL', 55, 2),
(10, 'Roll', 'Roll', 'Veg', 'Mushroom', 'DOUBLE MUSHROOM ROLL', 80, 2),
(11, 'Roll', 'Roll', 'Non Veg', 'Egg', 'SINGLE EGG ROLL', 30, 2),
(12, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'DOUBLE EGG ROLL', 45, 2),
(13, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE CHICKEN ROLL', 50, 2),
(14, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'DOUBLE CHICKEN ROLL', 80, 2),
(15, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG SINGLE CHICKEN ROLL', 65, 2),
(16, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG DOUBLE CHICKEN ROLL', 95, 2),
(17, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'DOUBLE EGG DOUBLE CHICKEN ROLL', 105, 2),
(18, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'SINGLE MUTTON ROLL', 70, 2),
(19, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'DOUBLE MUTTON ROLL', 120, 2),
(20, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'SINGLE EGG SINGLE MUTTON ROLL', 85, 2),
(21, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'SINGLE EGG DOUBLE MUTTON ROLL', 135, 2),
(22, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'DOUBLE EGG DOUBLE MUTTON ROLL', 150, 2),
(23, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE CHICKEN TIKKA ROLL', 70, 2),
(24, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'DOUBLE CHICKEN TIKKA ROLL', 120, 2),
(25, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG SINGLE CHICKEN TIKKA ROLL', 85, 2),
(26, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG DOUBLE CHICKEN TIKKA ROLL', 135, 2),
(27, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'DOUBLE EGG DOUBLE CHICKEN TIKKA ROLL', 150, 2),
(28, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE CHICKEN-SEEKH ROLL', 70, 2),
(29, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'DOUBLE CHICKEN-SEEKH ROLL', 120, 2),
(30, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG SINGLE CHICKEN-SEEKH ROLL', 85, 2),
(31, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG DOUBLE CHICKEN-SEEKH ROLL', 135, 2),
(32, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'DOUBLE EGG DOUBLE CHICKEN-SEEKH ROLL', 150, 2),
(33, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'SINGLE MUTTON-SEEKH ROLL', 80, 2),
(34, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'DOUBLE MUTTON-SEEKH ROLL', 130, 2),
(35, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'SINGLE EGG SINGLE MUTTON-SEEKH ROLL', 95, 2),
(36, 'Roll', 'Rumali', 'Non Veg', 'Chicken', 'CHICKEN RUMALI ROLL', 50, 2),
(37, 'Roll', 'Rumali', 'Non Veg', 'Chicken', 'CHICKEN TIKKA RUMALI ROLL', 70, 2),
(38, 'Roll', 'Rumali', 'Non Veg', 'Mutton', 'MUTTON RUMALI ROLL', 70, 2),
(39, 'Roll', 'Rumali', 'Non Veg', 'Chicken', 'CHICKEN-SEEKH RUMALI ROLL', 70, 2),
(40, 'Roll', 'Rumali', 'Non Veg', 'Chicken', 'DOUBLE CHICKEN SEEKH RUMALI ROLL', 120, 2),
(41, 'Roll', 'Rumali', 'Non Veg', 'Mutton', 'MUTTON-SEEKH RUMALI ROLL', 80, 2),
(42, 'Roll', 'Rumali', 'Non Veg', 'Mutton', 'DOUBLE MUTTON SEEKH RUMALI ROLL', 130, 2),
(43, 'Roll', 'Shawarma', 'Non Veg', 'Chicken', 'SINGLE SHAWARMA', 70, 2),
(44, 'Roll', 'Shawarma', 'Non Veg', 'Chicken', 'DOUBLE SHAWARMA', 110, 2),
(45, 'Chinese', 'Momo', 'Veg', 'Veg', 'VEG STEAMED', 30, 2),
(46, 'Chinese', 'Momo', 'Veg', 'Veg', 'VEG FRIED', 35, 2),
(47, 'Chinese', 'Momo', 'Veg', 'Veg', 'VEG PAN FRIED', 60, 2),
(48, 'Chinese', 'Momo', 'Non Veg', 'Chicken', 'CHICKEN STEAMED', 35, 2),
(49, 'Chinese', 'Momo', 'Non Veg', 'Chicken', 'CHICKEN FRIED', 50, 2),
(50, 'Chinese', 'Momo', 'Non Veg', 'Chicken', 'CHICKEN PAN FRIED', 70, 2),
(51, 'Chinese', 'Momo', 'Non Veg', 'Chicken', 'CHICKEN SCHEZWAN ', 70, 2),
(52, 'Chinese', 'Soup', 'Veg', 'Veg', 'VEG THAI SOUP', 80, 2),
(53, 'Chinese', 'Soup', 'Veg', 'Veg', 'VEG SWEET CORN SOUP', 80, 2),
(54, 'Chinese', 'Soup', 'Veg', 'Veg', 'VEG HOT N SOUR SOUP', 80, 2),
(55, 'Chinese', 'Soup', 'Veg', 'Veg', 'VEG LEMON CORIANDER', 80, 2),
(56, 'Chinese', 'Soup', 'Veg', 'Veg', 'VEG MANCHOW SOUP', 85, 2),
(57, 'Chinese', 'Soup', 'Non Veg', 'Egg', 'EGG SWEET CORN SOUP', 85, 2),
(58, 'Chinese', 'Soup', 'Non Veg', 'Egg', 'EGG HOT N SOUR SOUP', 85, 2),
(59, 'Chinese', 'Soup', 'Non Veg', 'Egg', 'EGG LEMON CORIANDER', 85, 2),
(60, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'CHICKEN CLEAR SOUP', 95, 2),
(61, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'CHICKEN SWEET CORN SOUP', 95, 2),
(62, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'CHICKEN HOT N SOUR SOUP', 95, 2),
(63, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'CHICKEN THAI SOUP', 95, 2),
(64, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'LUNG FUNG SOUP', 95, 2),
(65, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'CHICKEN LEMON CORIANDER', 95, 2),
(66, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'CHICKEN MANCHOW SOUP', 100, 2),
(67, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'CHICKEN MUSHROOM SOUP', 110, 2),
(68, 'Chinese', 'Starter', 'Veg', 'Potato', 'CRISPY CHILLI POTATO', 100, 2),
(69, 'Chinese', 'Starter', 'Veg', 'Baby Corn', 'FRIED BABY CORN', 130, 2),
(70, 'Chinese', 'Starter', 'Veg', 'Baby Corn', 'CHILLI GARLIC BABY CORN', 130, 2),
(71, 'Chinese', 'Starter', 'Veg', 'Corn', 'AMERICAN CORN', 140, 2),
(72, 'Chinese', 'Starter', 'Veg', 'Mushroom', 'CHILLI GARLIC BUTTON MUSHROOM', 140, 2),
(73, 'Chinese', 'Starter', 'Veg', 'Mushroom', 'PEPPER MUSHROOM', 140, 2),
(74, 'Chinese', 'Starter', 'Veg', 'Paneer', 'PANEER PAKORA (6 PCS)', 150, 2),
(75, 'Chinese', 'Starter', 'Non Veg', 'Fish', 'FISH PAKORA (6 PCS)', 180, 2),
(76, 'Chinese', 'Starter', 'Non Veg', 'Fish', 'PEPPER CHILLI GARLIC FISH (6 PCS)', 190, 2),
(77, 'Chinese', 'Starter', 'Non Veg', 'Fish', 'FISH FINGER (6 PCS)', 190, 2),
(78, 'Chinese', 'Starter', 'Non Veg', 'Fish', 'CRISPY FISH (6 PCS)', 190, 2),
(79, 'Chinese', 'Starter', 'Non Veg', 'Fish', 'PAN FRIED CHILLI FISH (6 PCS)', 190, 2),
(80, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'FRIED CHICKEN (6 PCS)', 130, 2),
(81, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'CHICKEN PAKORA (6 PCS)', 120, 2),
(82, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'CHICKEN LOLLYPOP', 130, 2),
(83, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'DRUMS OF HEAVEN (6 PCS)', 140, 2),
(84, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'CHILLI GARLIC DRUMS OF HEAVEN (6 PCS)', 150, 2),
(85, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'CHILLI GARLIC PEPPER CHICKEN (6 PCS)', 150, 2),
(86, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'PEPPER CHICKEN (6 PCS)', 150, 2),
(87, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'CRISPY CHICKEN (6 PCS)', 150, 2),
(88, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'CHICKEN 65 (6 PCS)', 160, 2),
(89, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'PAN FRIED CHILLI CHICKEN (6 PCS)', 170, 2),
(90, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'CRISPY HONEY CHILLI CHICKEN (6 PCS)', 170, 2),
(91, 'Chinese', 'Starter', 'Non Veg', 'Prawn', 'PRAWN PAKORA (6 PCS)', 210, 2),
(92, 'Chinese', 'Starter', 'Non Veg', 'Prawn', 'CRISPY PRAWN (6 PCS)', 230, 2),
(93, 'Chinese', 'Starter', 'Non Veg', 'Prawn', 'CHILLI GARLIC PRAWN (6 PCS)', 240, 2),
(94, 'Tandoor', 'Kebab', 'Veg', 'Paneer', 'PANEER TIKKA (6 PCS)', 150, 2),
(95, 'Tandoor', 'Kebab', 'Veg', 'Paneer', 'PANEER MALAI TIKKA (6 PCS)', 170, 2),
(96, 'Tandoor', 'Kebab', 'Veg', 'Paneer', 'PANEER SASHLIK (6 PCS)', 170, 2),
(97, 'Tandoor', 'Kebab', 'Veg', 'Mushroom', 'MUSHROOM TIKKA (6 PCS)', 170, 2),
(98, 'Tandoor', 'Kebab', 'Non Veg', 'Fish', 'FISH TIKKA (4 PCS)', 190, 2),
(99, 'Tandoor', 'Kebab', 'Non Veg', 'Fish', 'FISH IRANI KEBAB (4 PCS)', 200, 2),
(100, 'Tandoor', 'Kebab', 'Non Veg', 'Fish', 'FISH MAKHMALI KEBAB (4 PCS)', 210, 2),
(101, 'Tandoor', 'Kebab', 'Non Veg', 'Mutton', 'MUTTON BOTI KEBAB (6 PCS)', 250, 2),
(102, 'Tandoor', 'Kebab', 'Non Veg', 'Mutton', 'MUTTON TIKKA (6 PCS)', 250, 2),
(103, 'Tandoor', 'Kebab', 'Non Veg', 'Mutton', 'MUTTON SEEKH KEBAB (6 PCS)', 250, 2),
(104, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH TIKKA (6 PCS)', 150, 2),
(105, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH RESHMI KEBAB (6 PCS)', 170, 2),
(106, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH SEEKH KEBAB (6 PCS)', 170, 2),
(107, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH HARIYALI KEBAB (6 PCS)', 170, 2),
(108, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH LASOONI KEBAB (6 PCS)', 170, 2),
(109, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH KASTURI KEBAB (6 PCS)', 170, 2),
(110, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH MALAI KEBAB (6 PCS)', 190, 2),
(111, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH CHEESE KEBAB (6 PCS)', 190, 2),
(112, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH IRANI ', 170, 2),
(113, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH TANGRI KEBAB', 170, 2),
(114, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH AFGHANI TANGRI', 170, 2),
(115, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'TANDOORI MURGH HALF', 150, 2),
(116, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'TANDOORI MURGH FULL', 290, 2),
(117, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH AFGHANI TANDOORI HALF', 160, 2),
(118, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH AFGHANI TANDOORI FULL', 310, 2),
(119, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH PLATTER (9 KEBABS AND 1 TAGRI)', 350, 2),
(120, 'Chinese', 'Rice', 'Veg', 'Veg', 'VEG FRIED RICE', 100, 2),
(121, 'Chinese', 'Rice', 'Non Veg', 'Egg', 'EGG FRIED RICE', 110, 2),
(122, 'Chinese', 'Rice', 'Non Veg', 'Chicken', 'CHICKEN FRIED RICE', 120, 2),
(123, 'Chinese', 'Rice', 'Non Veg', 'Prawn', 'PRAWN FRIED RICE', 140, 2),
(124, 'Chinese', 'Rice', 'Non Veg', 'Mixed', 'MIXED FRIED RICE', 150, 2),
(125, 'Chinese', 'Rice', 'Veg', 'Veg', 'VEG SCHEZWAN FRIED RICE', 110, 2),
(126, 'Chinese', 'Rice', 'Non Veg', 'Egg', 'EGG SCHEZWAN FRIED RICE', 120, 2),
(127, 'Chinese', 'Rice', 'Non Veg', 'Chicken', 'CHICKEN SCHEZWAN FRIED RICE', 140, 2),
(128, 'Chinese', 'Rice', 'Non Veg', 'Prawn', 'PRAWN SCHEZWAN FRIED RICE', 150, 2),
(129, 'Chinese', 'Rice', 'Non Veg', 'Mixed', 'MIXED SCHEZWAN FRIED RICE', 160, 2),
(130, 'Chinese', 'Rice', 'Veg', 'Veg', 'VEG CHILLI GARLIC FRIED RICE', 110, 2),
(131, 'Chinese', 'Rice', 'Non Veg', 'Egg', 'EGG CHILLI GARLIC FRIED RICE', 120, 2),
(132, 'Chinese', 'Rice', 'Non Veg', 'Chicken', 'CHICKEN CHILLI GARLIC FRIED RICE', 140, 2),
(133, 'Chinese', 'Rice', 'Non Veg', 'Prawn', 'PRAWN CHILLI GARLIC FRIED RICE', 150, 2),
(134, 'Chinese', 'Rice', 'Non Veg', 'Mixed', 'MIXED CHILLI GARLIC FRIED RICE', 160, 2),
(135, 'Chinese', 'Rice', 'Veg', 'Veg', 'VEG CANTONESE FRIED RICE', 110, 2),
(136, 'Chinese', 'Rice', 'Non Veg', 'Egg', 'EGG CANTONESE FRIED RICE', 120, 2),
(137, 'Chinese', 'Rice', 'Non Veg', 'Chicken', 'CHICKEN CANTONESE FRIED RICE', 140, 2),
(138, 'Chinese', 'Rice', 'Non Veg', 'Prawn', 'PRAWN CANTONESE FRIED RICE', 150, 2),
(139, 'Chinese', 'Rice', 'Non Veg', 'Mixed', 'MIXED CANTONESE FRIED RICE', 160, 2),
(140, 'Chinese', 'Rice', 'Veg', 'Veg', 'VEG BUTTER GARLIC FRIED RICE', 110, 2),
(141, 'Chinese', 'Rice', 'Non Veg', 'Egg', 'EGG BUTTER GARLIC FRIED RICE', 120, 2),
(142, 'Chinese', 'Rice', 'Non Veg', 'Chicken', 'CHICKEN BUTTER GARLIC FRIED RICE', 140, 2),
(143, 'Chinese', 'Rice', 'Non Veg', 'Prawn', 'PRAWN BUTTER GARLIC FRIED RICE', 150, 2),
(144, 'Chinese', 'Rice', 'Non Veg', 'Mixed', 'MIXED BUTTER GARLIC FRIED RICE', 160, 2),
(145, 'Chinese', 'Noodles', 'Veg', 'Veg', 'VEG HAKKA NOODLES', 100, 2),
(146, 'Chinese', 'Noodles', 'Non Veg', 'Egg', 'EGG HAKKA NOODLES', 110, 2),
(147, 'Chinese', 'Noodles', 'Non Veg', 'Chicken', 'CHICKEN HAKKA NOODLES', 120, 2),
(148, 'Chinese', 'Noodles', 'Non Veg', 'Prawn', 'PRAWN HAKKA NOODLES', 140, 2),
(149, 'Chinese', 'Noodles', 'Non Veg', 'Mixed', 'MIXED HAKKA NOODLES', 150, 2),
(150, 'Chinese', 'Noodles', 'Veg', 'Veg', 'VEG SCHEZWAN HAKKA NOODLES', 110, 2),
(151, 'Chinese', 'Noodles', 'Non Veg', 'Egg', 'EGG SCHEZWAN HAKKA NOODLES', 120, 2),
(152, 'Chinese', 'Noodles', 'Non Veg', 'Chicken', 'CHICKEN SCHEZWAN HAKKA NOODLES', 140, 2),
(153, 'Chinese', 'Noodles', 'Non Veg', 'Prawn', 'PRAWN SCHEZWAN HAKKA NOODLES', 150, 2),
(154, 'Chinese', 'Noodles', 'Non Veg', 'Mixed', 'MIXED SCHEZWAN HAKKA NOODLES', 160, 2),
(155, 'Chinese', 'Noodles', 'Veg', 'Veg', 'VEG CHILLI GARLIC HAKKA NOODLES', 110, 2),
(156, 'Chinese', 'Noodles', 'Non Veg', 'Egg', 'EGG CHILLI GARLIC HAKKA NOODLES', 120, 2),
(157, 'Chinese', 'Noodles', 'Non Veg', 'Chicken', 'CHICKEN CHILLI GARLIC HAKKA NOODLES', 140, 2),
(158, 'Chinese', 'Noodles', 'Non Veg', 'Prawn', 'PRAWN CHILLI GARLIC HAKKA NOODLES', 150, 2),
(159, 'Chinese', 'Noodles', 'Non Veg', 'Mixed', 'MIXED CHILLI GARLIC HAKKA NOODLES', 160, 2),
(160, 'Chinese', 'Noodles', 'Veg', 'Veg', 'VEG CANTONESE GRAVY NOODLES', 110, 2),
(161, 'Chinese', 'Noodles', 'Non Veg', 'Egg', 'EGG CANTONESE GRAVY NOODLES', 120, 2),
(162, 'Chinese', 'Noodles', 'Non Veg', 'Chicken', 'CHICKEN CANTONESE GRAVY NOODLES', 140, 2),
(163, 'Chinese', 'Noodles', 'Non Veg', 'Prawn', 'PRAWN CANTONESE GRAVY NOODLES', 150, 2),
(164, 'Chinese', 'Noodles', 'Non Veg', 'Mixed', 'MIXED CANTONESE GRAVY NOODLES', 160, 2),
(165, 'Chinese', 'Gravy Noodles', 'Veg', 'Veg', 'VEG GRAVY NOODLES', 110, 2),
(166, 'Chinese', 'Gravy Noodles', 'Non Veg', 'Egg', 'EGG GRAVY NOODLES', 120, 2),
(167, 'Chinese', 'Gravy Noodles', 'Non Veg', 'Chicken', 'CHICKEN GRAVY NOODLES', 140, 2),
(168, 'Chinese', 'Gravy Noodles', 'Non Veg', 'Mixed', 'MIXED GRAVY NOODLES', 150, 2),
(169, 'Chinese', 'Chopsuey', 'Non Veg', 'Mixed', 'AMERICAN CHOPSUEY', 160, 2),
(170, 'Chinese', 'Side Dish', 'Veg', 'Paneer', 'CHILLI PANEER (6 PCS)', 150, 2),
(171, 'Chinese', 'Side Dish', 'Veg', 'Paneer', 'GARLIC PANEER (6 PCS)', 150, 2),
(172, 'Chinese', 'Side Dish', 'Veg', 'Paneer', 'PANEER MANCHURIAN (6 PCS)', 150, 2),
(173, 'Chinese', 'Side Dish', 'Veg', 'Paneer', 'SCHEZWAN PANEER (6 PCS)', 150, 2),
(174, 'Chinese', 'Side Dish', 'Veg', 'Paneer', 'PANEER SWEET N SOUR (6 PCS)', 150, 2),
(175, 'Chinese', 'Side Dish', 'Veg', 'Corn', 'CHILLI BABY CORN ', 170, 2),
(176, 'Chinese', 'Side Dish', 'Veg', 'Corn', 'GARLIC BABY CORN ', 170, 2),
(177, 'Chinese', 'Side Dish', 'Veg', 'Corn', 'CHILLI GARLIC BABY CORN ', 170, 2),
(178, 'Chinese', 'Side Dish', 'Veg', 'Corn', 'BABY CORN MANCHURIAN', 170, 2),
(179, 'Chinese', 'Side Dish', 'Veg', 'Corn', 'SCHEZWAN BABY CORN ', 170, 2),
(180, 'Chinese', 'Side Dish', 'Veg', 'Corn', 'LEMON BABY CORN ', 170, 2),
(181, 'Chinese', 'Side Dish', 'Veg', 'Mushroom', 'CHILLI MUSHROOM ', 170, 2),
(182, 'Chinese', 'Side Dish', 'Veg', 'Mushroom', 'GARLIC MUSHROOM ', 170, 2),
(183, 'Chinese', 'Side Dish', 'Veg', 'Mushroom', 'CHILLI GARLIC MUSHROOM ', 170, 2),
(184, 'Chinese', 'Side Dish', 'Veg', 'Mushroom', 'MUSHROOM MANCHURIAN', 170, 2),
(185, 'Chinese', 'Side Dish', 'Veg', 'Mushroom', 'SCHEZWAN MUSHROOM ', 170, 2),
(186, 'Chinese', 'Side Dish', 'Veg', 'Mushroom', 'LEMON MUSHROOM ', 170, 2),
(187, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'CHILLI CHICKEN (6 PCS)', 150, 2),
(188, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'GARLIC CHICKEN (6 PCS)', 150, 2),
(189, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'CHILLI GARLIC CHICKEN (6 PCS)', 150, 2),
(190, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN MANCHURIAN (6 PCS)', 150, 2),
(191, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'SCHEZWAN CHICKEN (6 PCS)', 150, 2),
(192, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'LEMON CHICKEN (6 PCS)', 150, 2),
(193, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'HUNAN CHICKEN (6 PCS)', 170, 2),
(194, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN SWEET N SOUR (6 PCS)', 170, 2),
(195, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN 65 (6 PCS)', 170, 2),
(196, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'CHILLI LEMON CHICKEN (6 PCS)', 200, 2),
(197, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'KUNG PAO CHICKEN (6 PCS)', 200, 2),
(198, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN IN BLACK BEAN SAUCE (6 PCS)', 210, 2),
(199, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'CHILLI FISH (6 PCS)', 200, 2),
(200, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'GARLIC FISH (6 PCS)', 200, 2),
(201, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'CHILLI GARLIC FISH (6 PCS)', 200, 2),
(202, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'FISH MANCHURIAN(6 PCS)', 200, 2),
(203, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'SCHEZWAN FISH (6 PCS)', 200, 2),
(204, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'LEMON FISH (6 PCS)', 200, 2),
(205, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'HUNAN FISH (6 PCS)', 210, 2),
(206, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'FISH SWEET N SOUR (6 PCS)', 210, 2),
(207, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'FISH 65 (6 PCS)', 210, 2),
(208, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'FISH IN MUSTARD SAUCE (6 PCS)', 220, 2),
(209, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'CHILLI LEMON FISH (6 PCS)', 220, 2),
(210, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'KUNG PAO FISH (6 PCS)', 220, 2),
(211, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'CHILLI PRAWN (6 PCS)', 230, 2),
(212, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'GARLIC PRAWN (6 PCS)', 230, 2),
(213, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'CHILLI GARLIC PRAWN (6 PCS)', 230, 2),
(214, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'PRAWN MANCHURIAN (6 PCS)', 230, 2),
(215, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'SCHEZWAN PRAWN (6 PCS)', 230, 2),
(216, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'LEMON PRAWN (6 PCS)', 230, 2),
(217, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'HUNAN PRAWN (6 PCS)', 250, 2),
(218, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'PRAWN SWEET N SOUR (6 PCS)', 250, 2),
(219, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'PRAWN 65 (6 PCS)', 250, 2),
(220, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'CHILLI LEMON PRAWN (6 PCS)', 250, 2),
(221, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'KUNG PAO PRAWN (6 PCS)', 270, 2),
(222, 'Indian', 'Rice', 'Veg', 'Veg', 'STEAMED RICE', 70, 2),
(223, 'Indian', 'Rice', 'Veg', 'Veg', 'JEERA RICE', 100, 2),
(224, 'Indian', 'Rice', 'Veg', 'Veg', 'VEG PULAO', 120, 2),
(225, 'Indian', 'Rice', 'Veg', 'Veg', 'KASHMIRI PULAO', 140, 2),
(226, 'Indian', 'Biriyani', 'Non Veg', 'Chicken', 'CHICKEN BIRIYANI', 150, 2),
(227, 'Indian', 'Biriyani', 'Non Veg', 'Mutton', 'MUTTON BIRIYANI', 170, 2),
(228, 'Indian', 'Bread', 'Veg', 'Roti', 'RUMALI ROTI', 15, 2),
(229, 'Indian', 'Bread', 'Veg', 'Roti', 'TANDOORI ROTI', 25, 2),
(230, 'Indian', 'Bread', 'Veg', 'Roti', 'BUTTER TANDOORI ROTI', 35, 2),
(231, 'Indian', 'Bread', 'Veg', 'Naan', 'PLAIN NAAN', 30, 2),
(232, 'Indian', 'Bread', 'Veg', 'Naan', 'BUTTER NAAN', 40, 2),
(233, 'Indian', 'Bread', 'Veg', 'Lachha', 'LACHHA PARATHA', 30, 2),
(234, 'Indian', 'Bread', 'Veg', 'Kulcha', 'KULCHA ', 40, 2),
(235, 'Indian', 'Bread', 'Veg', 'Kulcha', 'MASALA KULCHA', 70, 2),
(236, 'Indian', 'Side Dish', 'Veg', 'Dal', 'DAL FRY', 90, 2),
(237, 'Indian', 'Side Dish', 'Veg', 'Dal', 'DAL MAKHANI', 110, 2),
(238, 'Indian', 'Side Dish', 'Veg', 'Aloo', 'ALOO MUTTER', 110, 2),
(239, 'Indian', 'Side Dish', 'Veg', 'Aloo', 'JEERA ALOO', 110, 2),
(240, 'Indian', 'Side Dish', 'Veg', 'Aloo', 'DUM ALOO', 120, 2),
(241, 'Indian', 'Side Dish', 'Veg', 'Dal', 'VEG TADKA ', 110, 2),
(242, 'Indian', 'Side Dish', 'Veg', 'Veg', 'VEG SHAHI KOFTA', 130, 2),
(243, 'Indian', 'Side Dish', 'Veg', 'Veg', 'NAVRATAN KORMA', 130, 2),
(244, 'Indian', 'Side Dish', 'Veg', 'Paneer', 'MUTTER PANEER', 130, 2),
(245, 'Indian', 'Side Dish', 'Veg', 'Paneer', 'PANEER MASALA', 130, 2),
(246, 'Indian', 'Side Dish', 'Veg', 'Paneer', 'PANEER BUTTER MASALA', 140, 2),
(247, 'Indian', 'Side Dish', 'Veg', 'Paneer', 'KADHAI PANEER', 130, 2),
(248, 'Indian', 'Side Dish', 'Veg', 'Paneer', 'HANDI PANEER', 130, 2),
(249, 'Indian', 'Side Dish', 'Veg', 'Paneer', 'PANEER KOFTA', 140, 2),
(250, 'Indian', 'Side Dish', 'Veg', 'Paneer', 'PANEER MALAI KOFTA', 150, 2),
(251, 'Indian', 'Side Dish', 'Non Veg', 'Dal', 'EGG TADKA ', 120, 2),
(252, 'Indian', 'Side Dish', 'Veg', 'Dal', 'PANEER TADKA ', 130, 2),
(253, 'Indian', 'Side Dish', 'Non Veg', 'Dal', 'CHICKEN TADKA ', 130, 2),
(254, 'Indian', 'Side Dish', 'Non Veg', 'Dal', 'MUTTON KEEMA TADKA ', 150, 2),
(255, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN CHAAP', 140, 2),
(256, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN CURRY (4 PCS)', 150, 2),
(257, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN KASSA (4 PCS)', 160, 2),
(258, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN KORMA (4 PCS)', 160, 2),
(259, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN MASALA (4 PCS)', 160, 2),
(260, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN DOPiYAZA (4 PCS)', 160, 2),
(261, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN BHARTA', 170, 2),
(262, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN REZALA (4 PCS)', 180, 2),
(263, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'HANDI CHICKEN (4 PCS)', 190, 2),
(264, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'KADHAI CHICKEN (4 PCS)', 190, 2),
(265, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'TAWA CHICKEN (4 PCS)', 190, 2),
(266, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN BEGUM BAHAR (4 PCS)', 200, 2),
(267, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN TIKKA BUTTER MASALA (6 PCS)', 220, 2),
(268, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN TANGRI BUTTER MASALA (2 PCS)', 220, 2),
(269, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN TANDOORI BUTTER MASALA (2 PCS)', 220, 2),
(270, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN RESHMI BUTTER MASALA (6 PCS)', 220, 2),
(271, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN HARIYALI BUTTER MASALA (6 PCS)', 220, 2),
(272, 'Indian', 'Side Dish', 'Non Veg', 'Fish', 'FISH MASALA (4 PCS)', 200, 2),
(273, 'Indian', 'Side Dish', 'Non Veg', 'Fish', 'FISH TIKKA BUTTER MASALA (4 PCS)', 220, 2),
(274, 'Indian', 'Side Dish', 'Non Veg', 'Fish', 'FISH RESHMI BUTTER MASALA (4 PCS)', 250, 2),
(275, 'Indian', 'Side Dish', 'Non Veg', 'Fish', 'FISH BEGUM BAHAR (4 PCS)', 250, 2),
(276, 'Indian', 'Side Dish', 'Non Veg', 'Prawn', 'PRAWN MASALA', 240, 2),
(277, 'Indian', 'Side Dish', 'Non Veg', 'Prawn', 'PRAWN BUTTER MASALA', 240, 2),
(278, 'Indian', 'Side Dish', 'Non Veg', 'Prawn', 'PRAWN MALAI CURRY', 250, 2),
(279, 'Indian', 'Side Dish', 'Non Veg', 'Prawn', 'PRAWN BUTTER MASALA', 230, 2),
(280, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON CURRY (4 PCS)', 190, 2),
(281, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON KASSA (4 PCS)', 190, 2),
(282, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON DOPYAZA (4 PCS)', 190, 2),
(283, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON KORMA (4 PCS)', 190, 2),
(284, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON CHAAP (4 PCS)', 210, 2),
(285, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON MASALA (4 PCS)', 210, 2),
(286, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON KEEMA MASALA', 210, 2),
(287, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON REZALA (4 PCS)', 210, 2),
(288, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'TAWA MUTTON (4 PCS)', 230, 2),
(289, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'HANDI MUTTON (4 PCS)', 230, 2),
(290, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'KADHAI MUTTON (4 PCS)', 230, 2),
(291, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON BEGUM BAHAR (4 PCS)', 250, 2),
(292, 'Indian', 'Salad', 'Veg', 'Veg', 'GREEN SALAD', 50, 2),
(293, 'Indian', 'Salad', 'Veg', 'Veg', 'ONION SALAD', 50, 2),
(294, 'Chinese', 'Salad', 'Non Veg', 'Chicken', 'CHICKEN SALAD', 100, 2),
(295, 'Beverages', 'Beverages', 'Beverages', 'Water', 'MINERAL WATER', 0, 2),
(296, 'Beverages', 'Beverages', 'Beverages', 'Cold Drinks', 'THUMS UP', 30, 2),
(297, 'Beverages', 'Beverages', 'Beverages', 'Cold Drinks', 'LIMCA', 30, 2),
(298, 'Beverages', 'Beverages', 'Beverages', 'Cold Drinks', 'FANTA', 30, 2),
(299, 'Beverages', 'Beverages', 'Beverages', 'Cold Drinks', 'MASALA COLD DRINKS', 40, 2),
(300, 'Beverages', 'Beverages', 'Beverages', 'Soda', 'FRESH LIME SODA', 35, 2),
(301, 'Beverages', 'Beverages', 'Beverages', 'Soda', 'SWEET LIME SODA', 35, 2),
(302, 'Beverages', 'Beverages', 'Beverages', 'Soda', 'MASALA SODA', 35, 2),
(303, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'STRAWBERRY', 70, 2),
(304, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'VANILLA', 80, 2),
(305, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'TWO IN ONE', 80, 2),
(306, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'CHOCOLATE', 80, 2),
(307, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'BUTTER SCOTCH', 80, 2),
(308, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'MANGO', 80, 2),
(309, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'MANGO MASTANI', 110, 2),
(310, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'DREAMY RAINBOW', 110, 2),
(311, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'CHOCOLATE OVERLOAD', 120, 2),
(312, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'CRUNCHY OREO MAGIC', 130, 2),
(313, 'Roll', 'Roll', 'Veg', 'Aloo', 'SINGLE ALOO ROLL', 30, 2),
(314, 'Roll', 'Roll', 'Veg', 'Aloo', 'DOUBLE ALOO ROLL', 45, 2),
(315, 'Roll', 'Roll', 'Veg', 'Veg', 'SINGLE VEGGIE ROLL', 40, 2),
(316, 'Roll', 'Roll', 'Veg', 'Veg', 'DOUBLE VEGGIE ROLL', 50, 2),
(317, 'Roll', 'Roll', 'Veg', 'Paneer', 'SINGLE PANEER ROLL', 50, 2),
(318, 'Roll', 'Roll', 'Veg', 'Paneer', 'DOUBLE PANEER ROLL', 70, 2),
(319, 'Roll', 'Roll', 'Veg', 'Paneer', 'SINGLE PANEER BHURJI ROLL', 50, 2),
(320, 'Roll', 'Roll', 'Veg', 'Paneer', 'DOUBLE PANEER BHURJI ROLL', 70, 2),
(321, 'Roll', 'Roll', 'Veg', 'Mushroom', 'SINGLE MUSHROOM ROLL', 55, 2),
(322, 'Roll', 'Roll', 'Veg', 'Mushroom', 'DOUBLE MUSHROOM ROLL', 80, 2),
(323, 'Roll', 'Roll', 'Non Veg', 'Egg', 'SINGLE EGG ROLL', 30, 2),
(324, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'DOUBLE EGG ROLL', 45, 2),
(325, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE CHICKEN ROLL', 50, 2),
(326, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'DOUBLE CHICKEN ROLL', 80, 2),
(327, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG SINGLE CHICKEN ROLL', 65, 2),
(328, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG DOUBLE CHICKEN ROLL', 95, 2),
(329, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'DOUBLE EGG DOUBLE CHICKEN ROLL', 105, 2),
(330, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'SINGLE MUTTON ROLL', 70, 2),
(331, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'DOUBLE MUTTON ROLL', 120, 2),
(332, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'SINGLE EGG SINGLE MUTTON ROLL', 85, 2),
(333, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'SINGLE EGG DOUBLE MUTTON ROLL', 135, 2),
(334, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'DOUBLE EGG DOUBLE MUTTON ROLL', 150, 2),
(335, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE CHICKEN TIKKA ROLL', 70, 2),
(336, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'DOUBLE CHICKEN TIKKA ROLL', 120, 2),
(337, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG SINGLE CHICKEN TIKKA ROLL', 85, 2),
(338, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG DOUBLE CHICKEN TIKKA ROLL', 135, 2),
(339, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'DOUBLE EGG DOUBLE CHICKEN TIKKA ROLL', 150, 2),
(340, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE CHICKEN-SEEKH ROLL', 70, 2),
(341, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'DOUBLE CHICKEN-SEEKH ROLL', 120, 2),
(342, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG SINGLE CHICKEN-SEEKH ROLL', 85, 2),
(343, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG DOUBLE CHICKEN-SEEKH ROLL', 135, 2),
(344, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'DOUBLE EGG DOUBLE CHICKEN-SEEKH ROLL', 150, 2),
(345, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'SINGLE MUTTON-SEEKH ROLL', 80, 2),
(346, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'DOUBLE MUTTON-SEEKH ROLL', 130, 2),
(347, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'SINGLE EGG SINGLE MUTTON-SEEKH ROLL', 95, 2),
(348, 'Roll', 'Rumali', 'Non Veg', 'Chicken', 'CHICKEN RUMALI ROLL', 50, 2),
(349, 'Roll', 'Rumali', 'Non Veg', 'Chicken', 'CHICKEN TIKKA RUMALI ROLL', 70, 2),
(350, 'Roll', 'Rumali', 'Non Veg', 'Mutton', 'MUTTON RUMALI ROLL', 70, 2),
(351, 'Roll', 'Rumali', 'Non Veg', 'Chicken', 'CHICKEN-SEEKH RUMALI ROLL', 70, 2),
(352, 'Roll', 'Rumali', 'Non Veg', 'Chicken', 'DOUBLE CHICKEN SEEKH RUMALI ROLL', 120, 2),
(353, 'Roll', 'Rumali', 'Non Veg', 'Mutton', 'MUTTON-SEEKH RUMALI ROLL', 80, 2),
(354, 'Roll', 'Rumali', 'Non Veg', 'Mutton', 'DOUBLE MUTTON SEEKH RUMALI ROLL', 130, 2),
(355, 'Roll', 'Shawarma', 'Non Veg', 'Chicken', 'SINGLE SHAWARMA', 70, 2),
(356, 'Roll', 'Shawarma', 'Non Veg', 'Chicken', 'DOUBLE SHAWARMA', 110, 2),
(357, 'Chinese', 'Momo', 'Veg', 'Veg', 'VEG STEAMED', 30, 2),
(358, 'Chinese', 'Momo', 'Veg', 'Veg', 'VEG FRIED', 35, 2),
(359, 'Chinese', 'Momo', 'Veg', 'Veg', 'VEG PAN FRIED', 60, 2),
(360, 'Chinese', 'Momo', 'Non Veg', 'Chicken', 'CHICKEN STEAMED', 35, 2),
(361, 'Chinese', 'Momo', 'Non Veg', 'Chicken', 'CHICKEN FRIED', 50, 2),
(362, 'Chinese', 'Momo', 'Non Veg', 'Chicken', 'CHICKEN PAN FRIED', 70, 2),
(363, 'Chinese', 'Momo', 'Non Veg', 'Chicken', 'CHICKEN SCHEZWAN ', 70, 2),
(364, 'Chinese', 'Soup', 'Veg', 'Veg', 'VEG THAI SOUP', 80, 2),
(365, 'Chinese', 'Soup', 'Veg', 'Veg', 'VEG SWEET CORN SOUP', 80, 2),
(366, 'Chinese', 'Soup', 'Veg', 'Veg', 'VEG HOT N SOUR SOUP', 80, 2),
(367, 'Chinese', 'Soup', 'Veg', 'Veg', 'VEG LEMON CORIANDER', 80, 2),
(368, 'Chinese', 'Soup', 'Veg', 'Veg', 'VEG MANCHOW SOUP', 85, 2),
(369, 'Chinese', 'Soup', 'Non Veg', 'Egg', 'EGG SWEET CORN SOUP', 85, 2),
(370, 'Chinese', 'Soup', 'Non Veg', 'Egg', 'EGG HOT N SOUR SOUP', 85, 2),
(371, 'Chinese', 'Soup', 'Non Veg', 'Egg', 'EGG LEMON CORIANDER', 85, 2),
(372, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'CHICKEN CLEAR SOUP', 95, 2),
(373, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'CHICKEN SWEET CORN SOUP', 95, 2),
(374, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'CHICKEN HOT N SOUR SOUP', 95, 2),
(375, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'CHICKEN THAI SOUP', 95, 2),
(376, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'LUNG FUNG SOUP', 95, 2),
(377, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'CHICKEN LEMON CORIANDER', 95, 2),
(378, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'CHICKEN MANCHOW SOUP', 100, 2),
(379, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'CHICKEN MUSHROOM SOUP', 110, 2),
(380, 'Chinese', 'Starter', 'Veg', 'Potato', 'CRISPY CHILLI POTATO', 100, 2),
(381, 'Chinese', 'Starter', 'Veg', 'Baby Corn', 'FRIED BABY CORN', 130, 2),
(382, 'Chinese', 'Starter', 'Veg', 'Baby Corn', 'CHILLI GARLIC BABY CORN', 130, 2),
(383, 'Chinese', 'Starter', 'Veg', 'Corn', 'AMERICAN CORN', 140, 2),
(384, 'Chinese', 'Starter', 'Veg', 'Mushroom', 'CHILLI GARLIC BUTTON MUSHROOM', 140, 2),
(385, 'Chinese', 'Starter', 'Veg', 'Mushroom', 'PEPPER MUSHROOM', 140, 2),
(386, 'Chinese', 'Starter', 'Veg', 'Paneer', 'PANEER PAKORA (6 PCS)', 150, 2),
(387, 'Chinese', 'Starter', 'Non Veg', 'Fish', 'FISH PAKORA (6 PCS)', 180, 2),
(388, 'Chinese', 'Starter', 'Non Veg', 'Fish', 'PEPPER CHILLI GARLIC FISH (6 PCS)', 190, 2),
(389, 'Chinese', 'Starter', 'Non Veg', 'Fish', 'FISH FINGER (6 PCS)', 190, 2),
(390, 'Chinese', 'Starter', 'Non Veg', 'Fish', 'CRISPY FISH (6 PCS)', 190, 2),
(391, 'Chinese', 'Starter', 'Non Veg', 'Fish', 'PAN FRIED CHILLI FISH (6 PCS)', 190, 2),
(392, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'FRIED CHICKEN (6 PCS)', 130, 2),
(393, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'CHICKEN PAKORA (6 PCS)', 120, 2),
(394, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'CHICKEN LOLLYPOP', 130, 2),
(395, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'DRUMS OF HEAVEN (6 PCS)', 140, 2),
(396, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'CHILLI GARLIC DRUMS OF HEAVEN (6 PCS)', 150, 2),
(397, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'CHILLI GARLIC PEPPER CHICKEN (6 PCS)', 150, 2),
(398, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'PEPPER CHICKEN (6 PCS)', 150, 2),
(399, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'CRISPY CHICKEN (6 PCS)', 150, 2),
(400, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'CHICKEN 65 (6 PCS)', 160, 2),
(401, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'PAN FRIED CHILLI CHICKEN (6 PCS)', 170, 2),
(402, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'CRISPY HONEY CHILLI CHICKEN (6 PCS)', 170, 2),
(403, 'Chinese', 'Starter', 'Non Veg', 'Prawn', 'PRAWN PAKORA (6 PCS)', 210, 2),
(404, 'Chinese', 'Starter', 'Non Veg', 'Prawn', 'CRISPY PRAWN (6 PCS)', 230, 2),
(405, 'Chinese', 'Starter', 'Non Veg', 'Prawn', 'CHILLI GARLIC PRAWN (6 PCS)', 240, 2),
(406, 'Tandoor', 'Kebab', 'Veg', 'Paneer', 'PANEER TIKKA (6 PCS)', 150, 2),
(407, 'Tandoor', 'Kebab', 'Veg', 'Paneer', 'PANEER MALAI TIKKA (6 PCS)', 170, 2),
(408, 'Tandoor', 'Kebab', 'Veg', 'Paneer', 'PANEER SASHLIK (6 PCS)', 170, 2),
(409, 'Tandoor', 'Kebab', 'Veg', 'Mushroom', 'MUSHROOM TIKKA (6 PCS)', 170, 2),
(410, 'Tandoor', 'Kebab', 'Non Veg', 'Fish', 'FISH TIKKA (4 PCS)', 190, 2),
(411, 'Tandoor', 'Kebab', 'Non Veg', 'Fish', 'FISH IRANI KEBAB (4 PCS)', 200, 2),
(412, 'Tandoor', 'Kebab', 'Non Veg', 'Fish', 'FISH MAKHMALI KEBAB (4 PCS)', 210, 2),
(413, 'Tandoor', 'Kebab', 'Non Veg', 'Mutton', 'MUTTON BOTI KEBAB (6 PCS)', 250, 2),
(414, 'Tandoor', 'Kebab', 'Non Veg', 'Mutton', 'MUTTON TIKKA (6 PCS)', 250, 2),
(415, 'Tandoor', 'Kebab', 'Non Veg', 'Mutton', 'MUTTON SEEKH KEBAB (6 PCS)', 250, 2),
(416, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH TIKKA (6 PCS)', 150, 2),
(417, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH RESHMI KEBAB (6 PCS)', 170, 2),
(418, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH SEEKH KEBAB (6 PCS)', 170, 2),
(419, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH HARIYALI KEBAB (6 PCS)', 170, 2),
(420, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH LASOONI KEBAB (6 PCS)', 170, 2),
(421, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH KASTURI KEBAB (6 PCS)', 170, 2),
(422, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH MALAI KEBAB (6 PCS)', 190, 2),
(423, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH CHEESE KEBAB (6 PCS)', 190, 2),
(424, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH IRANI ', 170, 2),
(425, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH TANGRI KEBAB', 170, 2),
(426, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH AFGHANI TANGRI', 170, 2),
(427, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'TANDOORI MURGH HALF', 150, 2),
(428, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'TANDOORI MURGH FULL', 290, 2),
(429, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH AFGHANI TANDOORI HALF', 160, 2),
(430, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH AFGHANI TANDOORI FULL', 310, 2),
(431, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH PLATTER (9 KEBABS AND 1 TAGRI)', 350, 2),
(432, 'Chinese', 'Rice', 'Veg', 'Veg', 'VEG FRIED RICE', 100, 2),
(433, 'Chinese', 'Rice', 'Non Veg', 'Egg', 'EGG FRIED RICE', 110, 2),
(434, 'Chinese', 'Rice', 'Non Veg', 'Chicken', 'CHICKEN FRIED RICE', 120, 2),
(435, 'Chinese', 'Rice', 'Non Veg', 'Prawn', 'PRAWN FRIED RICE', 140, 2),
(436, 'Chinese', 'Rice', 'Non Veg', 'Mixed', 'MIXED FRIED RICE', 150, 2),
(437, 'Chinese', 'Rice', 'Veg', 'Veg', 'VEG SCHEZWAN FRIED RICE', 110, 2),
(438, 'Chinese', 'Rice', 'Non Veg', 'Egg', 'EGG SCHEZWAN FRIED RICE', 120, 2),
(439, 'Chinese', 'Rice', 'Non Veg', 'Chicken', 'CHICKEN SCHEZWAN FRIED RICE', 140, 2),
(440, 'Chinese', 'Rice', 'Non Veg', 'Prawn', 'PRAWN SCHEZWAN FRIED RICE', 150, 2),
(441, 'Chinese', 'Rice', 'Non Veg', 'Mixed', 'MIXED SCHEZWAN FRIED RICE', 160, 2),
(442, 'Chinese', 'Rice', 'Veg', 'Veg', 'VEG CHILLI GARLIC FRIED RICE', 110, 2),
(443, 'Chinese', 'Rice', 'Non Veg', 'Egg', 'EGG CHILLI GARLIC FRIED RICE', 120, 2),
(444, 'Chinese', 'Rice', 'Non Veg', 'Chicken', 'CHICKEN CHILLI GARLIC FRIED RICE', 140, 2),
(445, 'Chinese', 'Rice', 'Non Veg', 'Prawn', 'PRAWN CHILLI GARLIC FRIED RICE', 150, 2),
(446, 'Chinese', 'Rice', 'Non Veg', 'Mixed', 'MIXED CHILLI GARLIC FRIED RICE', 160, 2),
(447, 'Chinese', 'Rice', 'Veg', 'Veg', 'VEG CANTONESE FRIED RICE', 110, 2),
(448, 'Chinese', 'Rice', 'Non Veg', 'Egg', 'EGG CANTONESE FRIED RICE', 120, 2),
(449, 'Chinese', 'Rice', 'Non Veg', 'Chicken', 'CHICKEN CANTONESE FRIED RICE', 140, 2),
(450, 'Chinese', 'Rice', 'Non Veg', 'Prawn', 'PRAWN CANTONESE FRIED RICE', 150, 2),
(451, 'Chinese', 'Rice', 'Non Veg', 'Mixed', 'MIXED CANTONESE FRIED RICE', 160, 2),
(452, 'Chinese', 'Rice', 'Veg', 'Veg', 'VEG BUTTER GARLIC FRIED RICE', 110, 2),
(453, 'Chinese', 'Rice', 'Non Veg', 'Egg', 'EGG BUTTER GARLIC FRIED RICE', 120, 2),
(454, 'Chinese', 'Rice', 'Non Veg', 'Chicken', 'CHICKEN BUTTER GARLIC FRIED RICE', 140, 2),
(455, 'Chinese', 'Rice', 'Non Veg', 'Prawn', 'PRAWN BUTTER GARLIC FRIED RICE', 150, 2),
(456, 'Chinese', 'Rice', 'Non Veg', 'Mixed', 'MIXED BUTTER GARLIC FRIED RICE', 160, 2),
(457, 'Chinese', 'Noodles', 'Veg', 'Veg', 'VEG HAKKA NOODLES', 100, 2),
(458, 'Chinese', 'Noodles', 'Non Veg', 'Egg', 'EGG HAKKA NOODLES', 110, 2),
(459, 'Chinese', 'Noodles', 'Non Veg', 'Chicken', 'CHICKEN HAKKA NOODLES', 120, 2),
(460, 'Chinese', 'Noodles', 'Non Veg', 'Prawn', 'PRAWN HAKKA NOODLES', 140, 2),
(461, 'Chinese', 'Noodles', 'Non Veg', 'Mixed', 'MIXED HAKKA NOODLES', 150, 2),
(462, 'Chinese', 'Noodles', 'Veg', 'Veg', 'VEG SCHEZWAN HAKKA NOODLES', 110, 2),
(463, 'Chinese', 'Noodles', 'Non Veg', 'Egg', 'EGG SCHEZWAN HAKKA NOODLES', 120, 2),
(464, 'Chinese', 'Noodles', 'Non Veg', 'Chicken', 'CHICKEN SCHEZWAN HAKKA NOODLES', 140, 2),
(465, 'Chinese', 'Noodles', 'Non Veg', 'Prawn', 'PRAWN SCHEZWAN HAKKA NOODLES', 150, 2),
(466, 'Chinese', 'Noodles', 'Non Veg', 'Mixed', 'MIXED SCHEZWAN HAKKA NOODLES', 160, 2),
(467, 'Chinese', 'Noodles', 'Veg', 'Veg', 'VEG CHILLI GARLIC HAKKA NOODLES', 110, 2),
(468, 'Chinese', 'Noodles', 'Non Veg', 'Egg', 'EGG CHILLI GARLIC HAKKA NOODLES', 120, 2),
(469, 'Chinese', 'Noodles', 'Non Veg', 'Chicken', 'CHICKEN CHILLI GARLIC HAKKA NOODLES', 140, 2),
(470, 'Chinese', 'Noodles', 'Non Veg', 'Prawn', 'PRAWN CHILLI GARLIC HAKKA NOODLES', 150, 2),
(471, 'Chinese', 'Noodles', 'Non Veg', 'Mixed', 'MIXED CHILLI GARLIC HAKKA NOODLES', 160, 2),
(472, 'Chinese', 'Noodles', 'Veg', 'Veg', 'VEG CANTONESE GRAVY NOODLES', 110, 2),
(473, 'Chinese', 'Noodles', 'Non Veg', 'Egg', 'EGG CANTONESE GRAVY NOODLES', 120, 2),
(474, 'Chinese', 'Noodles', 'Non Veg', 'Chicken', 'CHICKEN CANTONESE GRAVY NOODLES', 140, 2),
(475, 'Chinese', 'Noodles', 'Non Veg', 'Prawn', 'PRAWN CANTONESE GRAVY NOODLES', 150, 2),
(476, 'Chinese', 'Noodles', 'Non Veg', 'Mixed', 'MIXED CANTONESE GRAVY NOODLES', 160, 2),
(477, 'Chinese', 'Gravy Noodles', 'Veg', 'Veg', 'VEG GRAVY NOODLES', 110, 2),
(478, 'Chinese', 'Gravy Noodles', 'Non Veg', 'Egg', 'EGG GRAVY NOODLES', 120, 2),
(479, 'Chinese', 'Gravy Noodles', 'Non Veg', 'Chicken', 'CHICKEN GRAVY NOODLES', 140, 2),
(480, 'Chinese', 'Gravy Noodles', 'Non Veg', 'Mixed', 'MIXED GRAVY NOODLES', 150, 2),
(481, 'Chinese', 'Chopsuey', 'Non Veg', 'Mixed', 'AMERICAN CHOPSUEY', 160, 2),
(482, 'Chinese', 'Side Dish', 'Veg', 'Paneer', 'CHILLI PANEER (6 PCS)', 150, 2),
(483, 'Chinese', 'Side Dish', 'Veg', 'Paneer', 'GARLIC PANEER (6 PCS)', 150, 2),
(484, 'Chinese', 'Side Dish', 'Veg', 'Paneer', 'PANEER MANCHURIAN (6 PCS)', 150, 2),
(485, 'Chinese', 'Side Dish', 'Veg', 'Paneer', 'SCHEZWAN PANEER (6 PCS)', 150, 2),
(486, 'Chinese', 'Side Dish', 'Veg', 'Paneer', 'PANEER SWEET N SOUR (6 PCS)', 150, 2),
(487, 'Chinese', 'Side Dish', 'Veg', 'Corn', 'CHILLI BABY CORN ', 170, 2),
(488, 'Chinese', 'Side Dish', 'Veg', 'Corn', 'GARLIC BABY CORN ', 170, 2),
(489, 'Chinese', 'Side Dish', 'Veg', 'Corn', 'CHILLI GARLIC BABY CORN ', 170, 2),
(490, 'Chinese', 'Side Dish', 'Veg', 'Corn', 'BABY CORN MANCHURIAN', 170, 2),
(491, 'Chinese', 'Side Dish', 'Veg', 'Corn', 'SCHEZWAN BABY CORN ', 170, 2),
(492, 'Chinese', 'Side Dish', 'Veg', 'Corn', 'LEMON BABY CORN ', 170, 2),
(493, 'Chinese', 'Side Dish', 'Veg', 'Mushroom', 'CHILLI MUSHROOM ', 170, 2),
(494, 'Chinese', 'Side Dish', 'Veg', 'Mushroom', 'GARLIC MUSHROOM ', 170, 2),
(495, 'Chinese', 'Side Dish', 'Veg', 'Mushroom', 'CHILLI GARLIC MUSHROOM ', 170, 2),
(496, 'Chinese', 'Side Dish', 'Veg', 'Mushroom', 'MUSHROOM MANCHURIAN', 170, 2),
(497, 'Chinese', 'Side Dish', 'Veg', 'Mushroom', 'SCHEZWAN MUSHROOM ', 170, 2),
(498, 'Chinese', 'Side Dish', 'Veg', 'Mushroom', 'LEMON MUSHROOM ', 170, 2),
(499, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'CHILLI CHICKEN (6 PCS)', 150, 2),
(500, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'GARLIC CHICKEN (6 PCS)', 150, 2),
(501, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'CHILLI GARLIC CHICKEN (6 PCS)', 150, 2),
(502, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN MANCHURIAN (6 PCS)', 150, 2),
(503, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'SCHEZWAN CHICKEN (6 PCS)', 150, 2),
(504, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'LEMON CHICKEN (6 PCS)', 150, 2),
(505, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'HUNAN CHICKEN (6 PCS)', 170, 2),
(506, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN SWEET N SOUR (6 PCS)', 170, 2),
(507, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN 65 (6 PCS)', 170, 2),
(508, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'CHILLI LEMON CHICKEN (6 PCS)', 200, 2),
(509, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'KUNG PAO CHICKEN (6 PCS)', 200, 2),
(510, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN IN BLACK BEAN SAUCE (6 PCS)', 210, 2),
(511, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'CHILLI FISH (6 PCS)', 200, 2),
(512, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'GARLIC FISH (6 PCS)', 200, 2),
(513, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'CHILLI GARLIC FISH (6 PCS)', 200, 2),
(514, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'FISH MANCHURIAN(6 PCS)', 200, 2),
(515, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'SCHEZWAN FISH (6 PCS)', 200, 2),
(516, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'LEMON FISH (6 PCS)', 200, 2),
(517, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'HUNAN FISH (6 PCS)', 210, 2),
(518, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'FISH SWEET N SOUR (6 PCS)', 210, 2),
(519, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'FISH 65 (6 PCS)', 210, 2),
(520, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'FISH IN MUSTARD SAUCE (6 PCS)', 220, 2),
(521, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'CHILLI LEMON FISH (6 PCS)', 220, 2),
(522, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'KUNG PAO FISH (6 PCS)', 220, 2),
(523, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'CHILLI PRAWN (6 PCS)', 230, 2),
(524, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'GARLIC PRAWN (6 PCS)', 230, 2),
(525, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'CHILLI GARLIC PRAWN (6 PCS)', 230, 2),
(526, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'PRAWN MANCHURIAN (6 PCS)', 230, 2),
(527, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'SCHEZWAN PRAWN (6 PCS)', 230, 2),
(528, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'LEMON PRAWN (6 PCS)', 230, 2),
(529, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'HUNAN PRAWN (6 PCS)', 250, 2),
(530, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'PRAWN SWEET N SOUR (6 PCS)', 250, 2),
(531, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'PRAWN 65 (6 PCS)', 250, 2),
(532, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'CHILLI LEMON PRAWN (6 PCS)', 250, 2),
(533, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'KUNG PAO PRAWN (6 PCS)', 270, 2),
(534, 'Indian', 'Rice', 'Veg', 'Veg', 'STEAMED RICE', 70, 2),
(535, 'Indian', 'Rice', 'Veg', 'Veg', 'JEERA RICE', 100, 2),
(536, 'Indian', 'Rice', 'Veg', 'Veg', 'VEG PULAO', 120, 2),
(537, 'Indian', 'Rice', 'Veg', 'Veg', 'KASHMIRI PULAO', 140, 2),
(538, 'Indian', 'Biriyani', 'Non Veg', 'Chicken', 'CHICKEN BIRIYANI', 150, 2),
(539, 'Indian', 'Biriyani', 'Non Veg', 'Mutton', 'MUTTON BIRIYANI', 170, 2),
(540, 'Indian', 'Bread', 'Veg', 'Roti', 'RUMALI ROTI', 15, 2),
(541, 'Indian', 'Bread', 'Veg', 'Roti', 'TANDOORI ROTI', 25, 2),
(542, 'Indian', 'Bread', 'Veg', 'Roti', 'BUTTER TANDOORI ROTI', 35, 2),
(543, 'Indian', 'Bread', 'Veg', 'Naan', 'PLAIN NAAN', 30, 2),
(544, 'Indian', 'Bread', 'Veg', 'Naan', 'BUTTER NAAN', 40, 2),
(545, 'Indian', 'Bread', 'Veg', 'Lachha', 'LACHHA PARATHA', 30, 2),
(546, 'Indian', 'Bread', 'Veg', 'Kulcha', 'KULCHA ', 40, 2),
(547, 'Indian', 'Bread', 'Veg', 'Kulcha', 'MASALA KULCHA', 70, 2),
(548, 'Indian', 'Side Dish', 'Veg', 'Dal', 'DAL FRY', 90, 2),
(549, 'Indian', 'Side Dish', 'Veg', 'Dal', 'DAL MAKHANI', 110, 2),
(550, 'Indian', 'Side Dish', 'Veg', 'Aloo', 'ALOO MUTTER', 110, 2),
(551, 'Indian', 'Side Dish', 'Veg', 'Aloo', 'JEERA ALOO', 110, 2),
(552, 'Indian', 'Side Dish', 'Veg', 'Aloo', 'DUM ALOO', 120, 2),
(553, 'Indian', 'Side Dish', 'Veg', 'Dal', 'VEG TADKA ', 110, 2),
(554, 'Indian', 'Side Dish', 'Veg', 'Veg', 'VEG SHAHI KOFTA', 130, 2),
(555, 'Indian', 'Side Dish', 'Veg', 'Veg', 'NAVRATAN KORMA', 130, 2),
(556, 'Indian', 'Side Dish', 'Veg', 'Paneer', 'MUTTER PANEER', 130, 2),
(557, 'Indian', 'Side Dish', 'Veg', 'Paneer', 'PANEER MASALA', 130, 2),
(558, 'Indian', 'Side Dish', 'Veg', 'Paneer', 'PANEER BUTTER MASALA', 140, 2),
(559, 'Indian', 'Side Dish', 'Veg', 'Paneer', 'KADHAI PANEER', 130, 2),
(560, 'Indian', 'Side Dish', 'Veg', 'Paneer', 'HANDI PANEER', 130, 2),
(561, 'Indian', 'Side Dish', 'Veg', 'Paneer', 'PANEER KOFTA', 140, 2),
(562, 'Indian', 'Side Dish', 'Veg', 'Paneer', 'PANEER MALAI KOFTA', 150, 2),
(563, 'Indian', 'Side Dish', 'Non Veg', 'Dal', 'EGG TADKA ', 120, 2),
(564, 'Indian', 'Side Dish', 'Veg', 'Dal', 'PANEER TADKA ', 130, 2),
(565, 'Indian', 'Side Dish', 'Non Veg', 'Dal', 'CHICKEN TADKA ', 130, 2),
(566, 'Indian', 'Side Dish', 'Non Veg', 'Dal', 'MUTTON KEEMA TADKA ', 150, 2),
(567, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN CHAAP', 140, 2),
(568, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN CURRY (4 PCS)', 150, 2),
(569, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN KASSA (4 PCS)', 160, 2),
(570, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN KORMA (4 PCS)', 160, 2),
(571, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN MASALA (4 PCS)', 160, 2),
(572, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN DOPiYAZA (4 PCS)', 160, 2),
(573, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN BHARTA', 170, 2),
(574, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN REZALA (4 PCS)', 180, 2),
(575, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'HANDI CHICKEN (4 PCS)', 190, 2),
(576, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'KADHAI CHICKEN (4 PCS)', 190, 2),
(577, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'TAWA CHICKEN (4 PCS)', 190, 2),
(578, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN BEGUM BAHAR (4 PCS)', 200, 2),
(579, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN TIKKA BUTTER MASALA (6 PCS)', 220, 2),
(580, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN TANGRI BUTTER MASALA (2 PCS)', 220, 2),
(581, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN TANDOORI BUTTER MASALA (2 PCS)', 220, 2),
(582, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN RESHMI BUTTER MASALA (6 PCS)', 220, 2),
(583, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN HARIYALI BUTTER MASALA (6 PCS)', 220, 2),
(584, 'Indian', 'Side Dish', 'Non Veg', 'Fish', 'FISH MASALA (4 PCS)', 200, 2),
(585, 'Indian', 'Side Dish', 'Non Veg', 'Fish', 'FISH TIKKA BUTTER MASALA (4 PCS)', 220, 2),
(586, 'Indian', 'Side Dish', 'Non Veg', 'Fish', 'FISH RESHMI BUTTER MASALA (4 PCS)', 250, 2),
(587, 'Indian', 'Side Dish', 'Non Veg', 'Fish', 'FISH BEGUM BAHAR (4 PCS)', 250, 2),
(588, 'Indian', 'Side Dish', 'Non Veg', 'Prawn', 'PRAWN MASALA', 240, 2),
(589, 'Indian', 'Side Dish', 'Non Veg', 'Prawn', 'PRAWN BUTTER MASALA', 240, 2),
(590, 'Indian', 'Side Dish', 'Non Veg', 'Prawn', 'PRAWN MALAI CURRY', 250, 2),
(591, 'Indian', 'Side Dish', 'Non Veg', 'Prawn', 'PRAWN BUTTER MASALA', 230, 2),
(592, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON CURRY (4 PCS)', 190, 2),
(593, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON KASSA (4 PCS)', 190, 2),
(594, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON DOPYAZA (4 PCS)', 190, 2),
(595, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON KORMA (4 PCS)', 190, 2),
(596, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON CHAAP (4 PCS)', 210, 2),
(597, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON MASALA (4 PCS)', 210, 2),
(598, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON KEEMA MASALA', 210, 2),
(599, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON REZALA (4 PCS)', 210, 2),
(600, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'TAWA MUTTON (4 PCS)', 230, 2),
(601, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'HANDI MUTTON (4 PCS)', 230, 2),
(602, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'KADHAI MUTTON (4 PCS)', 230, 2),
(603, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON BEGUM BAHAR (4 PCS)', 250, 2),
(604, 'Indian', 'Salad', 'Veg', 'Veg', 'GREEN SALAD', 50, 2),
(605, 'Indian', 'Salad', 'Veg', 'Veg', 'ONION SALAD', 50, 2),
(606, 'Chinese', 'Salad', 'Non Veg', 'Chicken', 'CHICKEN SALAD', 100, 2),
(607, 'Beverages', 'Beverages', 'Beverages', 'Water', 'MINERAL WATER', 0, 2),
(608, 'Beverages', 'Beverages', 'Beverages', 'Cold Drinks', 'THUMS UP', 30, 2),
(609, 'Beverages', 'Beverages', 'Beverages', 'Cold Drinks', 'LIMCA', 30, 2),
(610, 'Beverages', 'Beverages', 'Beverages', 'Cold Drinks', 'FANTA', 30, 2),
(611, 'Beverages', 'Beverages', 'Beverages', 'Cold Drinks', 'MASALA COLD DRINKS', 40, 2),
(612, 'Beverages', 'Beverages', 'Beverages', 'Soda', 'FRESH LIME SODA', 35, 2),
(613, 'Beverages', 'Beverages', 'Beverages', 'Soda', 'SWEET LIME SODA', 35, 2),
(614, 'Beverages', 'Beverages', 'Beverages', 'Soda', 'MASALA SODA', 35, 2),
(615, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'STRAWBERRY', 70, 2),
(616, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'VANILLA', 80, 2),
(617, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'TWO IN ONE', 80, 2),
(618, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'CHOCOLATE', 80, 2),
(619, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'BUTTER SCOTCH', 80, 2),
(620, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'MANGO', 80, 2),
(621, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'MANGO MASTANI', 110, 2),
(622, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'DREAMY RAINBOW', 110, 2),
(623, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'CHOCOLATE OVERLOAD', 120, 2),
(624, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'CRUNCHY OREO MAGIC', 130, 2),
(625, 'Roll', 'Roll', 'Veg', 'Aloo', 'SINGLE ALOO ROLL', 30, 3),
(626, 'Roll', 'Roll', 'Veg', 'Aloo', 'DOUBLE ALOO ROLL', 45, 3),
(627, 'Roll', 'Roll', 'Veg', 'Veg', 'SINGLE VEGGIE ROLL', 40, 3),
(628, 'Roll', 'Roll', 'Veg', 'Veg', 'DOUBLE VEGGIE ROLL', 50, 3),
(629, 'Roll', 'Roll', 'Veg', 'Paneer', 'SINGLE PANEER ROLL', 50, 3),
(630, 'Roll', 'Roll', 'Veg', 'Paneer', 'DOUBLE PANEER ROLL', 70, 3),
(631, 'Roll', 'Roll', 'Veg', 'Paneer', 'SINGLE PANEER BHURJI ROLL', 50, 3),
(632, 'Roll', 'Roll', 'Veg', 'Paneer', 'DOUBLE PANEER BHURJI ROLL', 70, 3),
(633, 'Roll', 'Roll', 'Veg', 'Mushroom', 'SINGLE MUSHROOM ROLL', 55, 3),
(634, 'Roll', 'Roll', 'Veg', 'Mushroom', 'DOUBLE MUSHROOM ROLL', 80, 3),
(635, 'Roll', 'Roll', 'Non Veg', 'Egg', 'SINGLE EGG ROLL', 30, 3);
INSERT INTO `menu_card` (`menu_id`, `level_1`, `level_2`, `level_3`, `level_4`, `level_5`, `price`, `fk_company`) VALUES
(636, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'DOUBLE EGG ROLL', 45, 3),
(637, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE CHICKEN ROLL', 50, 3),
(638, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'DOUBLE CHICKEN ROLL', 80, 3),
(639, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG SINGLE CHICKEN ROLL', 65, 3),
(640, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG DOUBLE CHICKEN ROLL', 95, 3),
(641, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'DOUBLE EGG DOUBLE CHICKEN ROLL', 105, 3),
(642, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'SINGLE MUTTON ROLL', 70, 3),
(643, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'DOUBLE MUTTON ROLL', 120, 3),
(644, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'SINGLE EGG SINGLE MUTTON ROLL', 85, 3),
(645, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'SINGLE EGG DOUBLE MUTTON ROLL', 135, 3),
(646, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'DOUBLE EGG DOUBLE MUTTON ROLL', 150, 3),
(647, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE CHICKEN TIKKA ROLL', 70, 3),
(648, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'DOUBLE CHICKEN TIKKA ROLL', 120, 3),
(649, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG SINGLE CHICKEN TIKKA ROLL', 85, 3),
(650, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG DOUBLE CHICKEN TIKKA ROLL', 135, 3),
(651, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'DOUBLE EGG DOUBLE CHICKEN TIKKA ROLL', 150, 3),
(652, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE CHICKEN-SEEKH ROLL', 70, 3),
(653, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'DOUBLE CHICKEN-SEEKH ROLL', 120, 3),
(654, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG SINGLE CHICKEN-SEEKH ROLL', 85, 3),
(655, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'SINGLE EGG DOUBLE CHICKEN-SEEKH ROLL', 135, 3),
(656, 'Roll', 'Roll', 'Non Veg', 'Chicken', 'DOUBLE EGG DOUBLE CHICKEN-SEEKH ROLL', 150, 3),
(657, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'SINGLE MUTTON-SEEKH ROLL', 80, 3),
(658, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'DOUBLE MUTTON-SEEKH ROLL', 130, 3),
(659, 'Roll', 'Roll', 'Non Veg', 'Mutton', 'SINGLE EGG SINGLE MUTTON-SEEKH ROLL', 95, 3),
(660, 'Roll', 'Rumali', 'Non Veg', 'Chicken', 'CHICKEN RUMALI ROLL', 50, 3),
(661, 'Roll', 'Rumali', 'Non Veg', 'Chicken', 'CHICKEN TIKKA RUMALI ROLL', 70, 3),
(662, 'Roll', 'Rumali', 'Non Veg', 'Mutton', 'MUTTON RUMALI ROLL', 70, 3),
(663, 'Roll', 'Rumali', 'Non Veg', 'Chicken', 'CHICKEN-SEEKH RUMALI ROLL', 70, 3),
(664, 'Roll', 'Rumali', 'Non Veg', 'Chicken', 'DOUBLE CHICKEN SEEKH RUMALI ROLL', 120, 3),
(665, 'Roll', 'Rumali', 'Non Veg', 'Mutton', 'MUTTON-SEEKH RUMALI ROLL', 80, 3),
(666, 'Roll', 'Rumali', 'Non Veg', 'Mutton', 'DOUBLE MUTTON SEEKH RUMALI ROLL', 130, 3),
(667, 'Roll', 'Shawarma', 'Non Veg', 'Chicken', 'SINGLE SHAWARMA', 70, 3),
(668, 'Roll', 'Shawarma', 'Non Veg', 'Chicken', 'DOUBLE SHAWARMA', 110, 3),
(669, 'Chinese', 'Momo', 'Veg', 'Veg', 'VEG STEAMED', 30, 3),
(670, 'Chinese', 'Momo', 'Veg', 'Veg', 'VEG FRIED', 35, 3),
(671, 'Chinese', 'Momo', 'Veg', 'Veg', 'VEG PAN FRIED', 60, 3),
(672, 'Chinese', 'Momo', 'Non Veg', 'Chicken', 'CHICKEN STEAMED', 35, 3),
(673, 'Chinese', 'Momo', 'Non Veg', 'Chicken', 'CHICKEN FRIED', 50, 3),
(674, 'Chinese', 'Momo', 'Non Veg', 'Chicken', 'CHICKEN PAN FRIED', 70, 3),
(675, 'Chinese', 'Momo', 'Non Veg', 'Chicken', 'CHICKEN SCHEZWAN ', 70, 3),
(676, 'Chinese', 'Soup', 'Veg', 'Veg', 'VEG THAI SOUP', 80, 3),
(677, 'Chinese', 'Soup', 'Veg', 'Veg', 'VEG SWEET CORN SOUP', 80, 3),
(678, 'Chinese', 'Soup', 'Veg', 'Veg', 'VEG HOT N SOUR SOUP', 80, 3),
(679, 'Chinese', 'Soup', 'Veg', 'Veg', 'VEG LEMON CORIANDER', 80, 3),
(680, 'Chinese', 'Soup', 'Veg', 'Veg', 'VEG MANCHOW SOUP', 85, 3),
(681, 'Chinese', 'Soup', 'Non Veg', 'Egg', 'EGG SWEET CORN SOUP', 85, 3),
(682, 'Chinese', 'Soup', 'Non Veg', 'Egg', 'EGG HOT N SOUR SOUP', 85, 3),
(683, 'Chinese', 'Soup', 'Non Veg', 'Egg', 'EGG LEMON CORIANDER', 85, 3),
(684, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'CHICKEN CLEAR SOUP', 95, 3),
(685, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'CHICKEN SWEET CORN SOUP', 95, 3),
(686, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'CHICKEN HOT N SOUR SOUP', 95, 3),
(687, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'CHICKEN THAI SOUP', 95, 3),
(688, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'LUNG FUNG SOUP', 95, 3),
(689, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'CHICKEN LEMON CORIANDER', 95, 3),
(690, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'CHICKEN MANCHOW SOUP', 100, 3),
(691, 'Chinese', 'Soup', 'Non Veg', 'Chicken', 'CHICKEN MUSHROOM SOUP', 110, 3),
(692, 'Chinese', 'Starter', 'Veg', 'Potato', 'CRISPY CHILLI POTATO', 100, 3),
(693, 'Chinese', 'Starter', 'Veg', 'Baby Corn', 'FRIED BABY CORN', 130, 3),
(694, 'Chinese', 'Starter', 'Veg', 'Baby Corn', 'CHILLI GARLIC BABY CORN', 130, 3),
(695, 'Chinese', 'Starter', 'Veg', 'Corn', 'AMERICAN CORN', 140, 3),
(696, 'Chinese', 'Starter', 'Veg', 'Mushroom', 'CHILLI GARLIC BUTTON MUSHROOM', 140, 3),
(697, 'Chinese', 'Starter', 'Veg', 'Mushroom', 'PEPPER MUSHROOM', 140, 3),
(698, 'Chinese', 'Starter', 'Veg', 'Paneer', 'PANEER PAKORA (6 PCS)', 150, 3),
(699, 'Chinese', 'Starter', 'Non Veg', 'Fish', 'FISH PAKORA (6 PCS)', 180, 3),
(700, 'Chinese', 'Starter', 'Non Veg', 'Fish', 'PEPPER CHILLI GARLIC FISH (6 PCS)', 190, 3),
(701, 'Chinese', 'Starter', 'Non Veg', 'Fish', 'FISH FINGER (6 PCS)', 190, 3),
(702, 'Chinese', 'Starter', 'Non Veg', 'Fish', 'CRISPY FISH (6 PCS)', 190, 3),
(703, 'Chinese', 'Starter', 'Non Veg', 'Fish', 'PAN FRIED CHILLI FISH (6 PCS)', 190, 3),
(704, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'FRIED CHICKEN (6 PCS)', 130, 3),
(705, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'CHICKEN PAKORA (6 PCS)', 120, 3),
(706, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'CHICKEN LOLLYPOP', 130, 3),
(707, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'DRUMS OF HEAVEN (6 PCS)', 140, 3),
(708, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'CHILLI GARLIC DRUMS OF HEAVEN (6 PCS)', 150, 3),
(709, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'CHILLI GARLIC PEPPER CHICKEN (6 PCS)', 150, 3),
(710, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'PEPPER CHICKEN (6 PCS)', 150, 3),
(711, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'CRISPY CHICKEN (6 PCS)', 150, 3),
(712, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'CHICKEN 65 (6 PCS)', 160, 3),
(713, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'PAN FRIED CHILLI CHICKEN (6 PCS)', 170, 3),
(714, 'Chinese', 'Starter', 'Non Veg', 'Chicken', 'CRISPY HONEY CHILLI CHICKEN (6 PCS)', 170, 3),
(715, 'Chinese', 'Starter', 'Non Veg', 'Prawn', 'PRAWN PAKORA (6 PCS)', 210, 3),
(716, 'Chinese', 'Starter', 'Non Veg', 'Prawn', 'CRISPY PRAWN (6 PCS)', 230, 3),
(717, 'Chinese', 'Starter', 'Non Veg', 'Prawn', 'CHILLI GARLIC PRAWN (6 PCS)', 240, 3),
(718, 'Tandoor', 'Kebab', 'Veg', 'Paneer', 'PANEER TIKKA (6 PCS)', 150, 3),
(719, 'Tandoor', 'Kebab', 'Veg', 'Paneer', 'PANEER MALAI TIKKA (6 PCS)', 170, 3),
(720, 'Tandoor', 'Kebab', 'Veg', 'Paneer', 'PANEER SASHLIK (6 PCS)', 170, 3),
(721, 'Tandoor', 'Kebab', 'Veg', 'Mushroom', 'MUSHROOM TIKKA (6 PCS)', 170, 3),
(722, 'Tandoor', 'Kebab', 'Non Veg', 'Fish', 'FISH TIKKA (4 PCS)', 190, 3),
(723, 'Tandoor', 'Kebab', 'Non Veg', 'Fish', 'FISH IRANI KEBAB (4 PCS)', 200, 3),
(724, 'Tandoor', 'Kebab', 'Non Veg', 'Fish', 'FISH MAKHMALI KEBAB (4 PCS)', 210, 3),
(725, 'Tandoor', 'Kebab', 'Non Veg', 'Mutton', 'MUTTON BOTI KEBAB (6 PCS)', 250, 3),
(726, 'Tandoor', 'Kebab', 'Non Veg', 'Mutton', 'MUTTON TIKKA (6 PCS)', 250, 3),
(727, 'Tandoor', 'Kebab', 'Non Veg', 'Mutton', 'MUTTON SEEKH KEBAB (6 PCS)', 250, 3),
(728, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH TIKKA (6 PCS)', 150, 3),
(729, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH RESHMI KEBAB (6 PCS)', 170, 3),
(730, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH SEEKH KEBAB (6 PCS)', 170, 3),
(731, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH HARIYALI KEBAB (6 PCS)', 170, 3),
(732, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH LASOONI KEBAB (6 PCS)', 170, 3),
(733, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH KASTURI KEBAB (6 PCS)', 170, 3),
(734, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH MALAI KEBAB (6 PCS)', 190, 3),
(735, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH CHEESE KEBAB (6 PCS)', 190, 3),
(736, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH IRANI ', 170, 3),
(737, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH TANGRI KEBAB', 170, 3),
(738, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH AFGHANI TANGRI', 170, 3),
(739, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'TANDOORI MURGH HALF', 150, 3),
(740, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'TANDOORI MURGH FULL', 290, 3),
(741, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH AFGHANI TANDOORI HALF', 160, 3),
(742, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH AFGHANI TANDOORI FULL', 310, 3),
(743, 'Tandoor', 'Kebab', 'Non Veg', 'Chicken', 'MURGH PLATTER (9 KEBABS AND 1 TAGRI)', 350, 3),
(744, 'Chinese', 'Rice', 'Veg', 'Veg', 'VEG FRIED RICE', 100, 3),
(745, 'Chinese', 'Rice', 'Non Veg', 'Egg', 'EGG FRIED RICE', 110, 3),
(746, 'Chinese', 'Rice', 'Non Veg', 'Chicken', 'CHICKEN FRIED RICE', 120, 3),
(747, 'Chinese', 'Rice', 'Non Veg', 'Prawn', 'PRAWN FRIED RICE', 140, 3),
(748, 'Chinese', 'Rice', 'Non Veg', 'Mixed', 'MIXED FRIED RICE', 150, 3),
(749, 'Chinese', 'Rice', 'Veg', 'Veg', 'VEG SCHEZWAN FRIED RICE', 110, 3),
(750, 'Chinese', 'Rice', 'Non Veg', 'Egg', 'EGG SCHEZWAN FRIED RICE', 120, 3),
(751, 'Chinese', 'Rice', 'Non Veg', 'Chicken', 'CHICKEN SCHEZWAN FRIED RICE', 140, 3),
(752, 'Chinese', 'Rice', 'Non Veg', 'Prawn', 'PRAWN SCHEZWAN FRIED RICE', 150, 3),
(753, 'Chinese', 'Rice', 'Non Veg', 'Mixed', 'MIXED SCHEZWAN FRIED RICE', 160, 3),
(754, 'Chinese', 'Rice', 'Veg', 'Veg', 'VEG CHILLI GARLIC FRIED RICE', 110, 3),
(755, 'Chinese', 'Rice', 'Non Veg', 'Egg', 'EGG CHILLI GARLIC FRIED RICE', 120, 3),
(756, 'Chinese', 'Rice', 'Non Veg', 'Chicken', 'CHICKEN CHILLI GARLIC FRIED RICE', 140, 3),
(757, 'Chinese', 'Rice', 'Non Veg', 'Prawn', 'PRAWN CHILLI GARLIC FRIED RICE', 150, 3),
(758, 'Chinese', 'Rice', 'Non Veg', 'Mixed', 'MIXED CHILLI GARLIC FRIED RICE', 160, 3),
(759, 'Chinese', 'Rice', 'Veg', 'Veg', 'VEG CANTONESE FRIED RICE', 110, 3),
(760, 'Chinese', 'Rice', 'Non Veg', 'Egg', 'EGG CANTONESE FRIED RICE', 120, 3),
(761, 'Chinese', 'Rice', 'Non Veg', 'Chicken', 'CHICKEN CANTONESE FRIED RICE', 140, 3),
(762, 'Chinese', 'Rice', 'Non Veg', 'Prawn', 'PRAWN CANTONESE FRIED RICE', 150, 3),
(763, 'Chinese', 'Rice', 'Non Veg', 'Mixed', 'MIXED CANTONESE FRIED RICE', 160, 3),
(764, 'Chinese', 'Rice', 'Veg', 'Veg', 'VEG BUTTER GARLIC FRIED RICE', 110, 3),
(765, 'Chinese', 'Rice', 'Non Veg', 'Egg', 'EGG BUTTER GARLIC FRIED RICE', 120, 3),
(766, 'Chinese', 'Rice', 'Non Veg', 'Chicken', 'CHICKEN BUTTER GARLIC FRIED RICE', 140, 3),
(767, 'Chinese', 'Rice', 'Non Veg', 'Prawn', 'PRAWN BUTTER GARLIC FRIED RICE', 150, 3),
(768, 'Chinese', 'Rice', 'Non Veg', 'Mixed', 'MIXED BUTTER GARLIC FRIED RICE', 160, 3),
(769, 'Chinese', 'Noodles', 'Veg', 'Veg', 'VEG HAKKA NOODLES', 100, 3),
(770, 'Chinese', 'Noodles', 'Non Veg', 'Egg', 'EGG HAKKA NOODLES', 110, 3),
(771, 'Chinese', 'Noodles', 'Non Veg', 'Chicken', 'CHICKEN HAKKA NOODLES', 120, 3),
(772, 'Chinese', 'Noodles', 'Non Veg', 'Prawn', 'PRAWN HAKKA NOODLES', 140, 3),
(773, 'Chinese', 'Noodles', 'Non Veg', 'Mixed', 'MIXED HAKKA NOODLES', 150, 3),
(774, 'Chinese', 'Noodles', 'Veg', 'Veg', 'VEG SCHEZWAN HAKKA NOODLES', 110, 3),
(775, 'Chinese', 'Noodles', 'Non Veg', 'Egg', 'EGG SCHEZWAN HAKKA NOODLES', 120, 3),
(776, 'Chinese', 'Noodles', 'Non Veg', 'Chicken', 'CHICKEN SCHEZWAN HAKKA NOODLES', 140, 3),
(777, 'Chinese', 'Noodles', 'Non Veg', 'Prawn', 'PRAWN SCHEZWAN HAKKA NOODLES', 150, 3),
(778, 'Chinese', 'Noodles', 'Non Veg', 'Mixed', 'MIXED SCHEZWAN HAKKA NOODLES', 160, 3),
(779, 'Chinese', 'Noodles', 'Veg', 'Veg', 'VEG CHILLI GARLIC HAKKA NOODLES', 110, 3),
(780, 'Chinese', 'Noodles', 'Non Veg', 'Egg', 'EGG CHILLI GARLIC HAKKA NOODLES', 120, 3),
(781, 'Chinese', 'Noodles', 'Non Veg', 'Chicken', 'CHICKEN CHILLI GARLIC HAKKA NOODLES', 140, 3),
(782, 'Chinese', 'Noodles', 'Non Veg', 'Prawn', 'PRAWN CHILLI GARLIC HAKKA NOODLES', 150, 3),
(783, 'Chinese', 'Noodles', 'Non Veg', 'Mixed', 'MIXED CHILLI GARLIC HAKKA NOODLES', 160, 3),
(784, 'Chinese', 'Noodles', 'Veg', 'Veg', 'VEG CANTONESE GRAVY NOODLES', 110, 3),
(785, 'Chinese', 'Noodles', 'Non Veg', 'Egg', 'EGG CANTONESE GRAVY NOODLES', 120, 3),
(786, 'Chinese', 'Noodles', 'Non Veg', 'Chicken', 'CHICKEN CANTONESE GRAVY NOODLES', 140, 3),
(787, 'Chinese', 'Noodles', 'Non Veg', 'Prawn', 'PRAWN CANTONESE GRAVY NOODLES', 150, 3),
(788, 'Chinese', 'Noodles', 'Non Veg', 'Mixed', 'MIXED CANTONESE GRAVY NOODLES', 160, 3),
(789, 'Chinese', 'Gravy Noodles', 'Veg', 'Veg', 'VEG GRAVY NOODLES', 110, 3),
(790, 'Chinese', 'Gravy Noodles', 'Non Veg', 'Egg', 'EGG GRAVY NOODLES', 120, 3),
(791, 'Chinese', 'Gravy Noodles', 'Non Veg', 'Chicken', 'CHICKEN GRAVY NOODLES', 140, 3),
(792, 'Chinese', 'Gravy Noodles', 'Non Veg', 'Mixed', 'MIXED GRAVY NOODLES', 150, 3),
(793, 'Chinese', 'Chopsuey', 'Non Veg', 'Mixed', 'AMERICAN CHOPSUEY', 160, 3),
(794, 'Chinese', 'Side Dish', 'Veg', 'Paneer', 'CHILLI PANEER (6 PCS)', 150, 3),
(795, 'Chinese', 'Side Dish', 'Veg', 'Paneer', 'GARLIC PANEER (6 PCS)', 150, 3),
(796, 'Chinese', 'Side Dish', 'Veg', 'Paneer', 'PANEER MANCHURIAN (6 PCS)', 150, 3),
(797, 'Chinese', 'Side Dish', 'Veg', 'Paneer', 'SCHEZWAN PANEER (6 PCS)', 150, 3),
(798, 'Chinese', 'Side Dish', 'Veg', 'Paneer', 'PANEER SWEET N SOUR (6 PCS)', 150, 3),
(799, 'Chinese', 'Side Dish', 'Veg', 'Corn', 'CHILLI BABY CORN ', 170, 3),
(800, 'Chinese', 'Side Dish', 'Veg', 'Corn', 'GARLIC BABY CORN ', 170, 3),
(801, 'Chinese', 'Side Dish', 'Veg', 'Corn', 'CHILLI GARLIC BABY CORN ', 170, 3),
(802, 'Chinese', 'Side Dish', 'Veg', 'Corn', 'BABY CORN MANCHURIAN', 170, 3),
(803, 'Chinese', 'Side Dish', 'Veg', 'Corn', 'SCHEZWAN BABY CORN ', 170, 3),
(804, 'Chinese', 'Side Dish', 'Veg', 'Corn', 'LEMON BABY CORN ', 170, 3),
(805, 'Chinese', 'Side Dish', 'Veg', 'Mushroom', 'CHILLI MUSHROOM ', 170, 3),
(806, 'Chinese', 'Side Dish', 'Veg', 'Mushroom', 'GARLIC MUSHROOM ', 170, 3),
(807, 'Chinese', 'Side Dish', 'Veg', 'Mushroom', 'CHILLI GARLIC MUSHROOM ', 170, 3),
(808, 'Chinese', 'Side Dish', 'Veg', 'Mushroom', 'MUSHROOM MANCHURIAN', 170, 3),
(809, 'Chinese', 'Side Dish', 'Veg', 'Mushroom', 'SCHEZWAN MUSHROOM ', 170, 3),
(810, 'Chinese', 'Side Dish', 'Veg', 'Mushroom', 'LEMON MUSHROOM ', 170, 3),
(811, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'CHILLI CHICKEN (6 PCS)', 150, 3),
(812, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'GARLIC CHICKEN (6 PCS)', 150, 3),
(813, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'CHILLI GARLIC CHICKEN (6 PCS)', 150, 3),
(814, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN MANCHURIAN (6 PCS)', 150, 3),
(815, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'SCHEZWAN CHICKEN (6 PCS)', 150, 3),
(816, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'LEMON CHICKEN (6 PCS)', 150, 3),
(817, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'HUNAN CHICKEN (6 PCS)', 170, 3),
(818, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN SWEET N SOUR (6 PCS)', 170, 3),
(819, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN 65 (6 PCS)', 170, 3),
(820, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'CHILLI LEMON CHICKEN (6 PCS)', 200, 3),
(821, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'KUNG PAO CHICKEN (6 PCS)', 200, 3),
(822, 'Chinese', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN IN BLACK BEAN SAUCE (6 PCS)', 210, 3),
(823, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'CHILLI FISH (6 PCS)', 200, 3),
(824, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'GARLIC FISH (6 PCS)', 200, 3),
(825, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'CHILLI GARLIC FISH (6 PCS)', 200, 3),
(826, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'FISH MANCHURIAN(6 PCS)', 200, 3),
(827, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'SCHEZWAN FISH (6 PCS)', 200, 3),
(828, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'LEMON FISH (6 PCS)', 200, 3),
(829, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'HUNAN FISH (6 PCS)', 210, 3),
(830, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'FISH SWEET N SOUR (6 PCS)', 210, 3),
(831, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'FISH 65 (6 PCS)', 210, 3),
(832, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'FISH IN MUSTARD SAUCE (6 PCS)', 220, 3),
(833, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'CHILLI LEMON FISH (6 PCS)', 220, 3),
(834, 'Chinese', 'Side Dish', 'Non Veg', 'Fish', 'KUNG PAO FISH (6 PCS)', 220, 3),
(835, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'CHILLI PRAWN (6 PCS)', 230, 3),
(836, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'GARLIC PRAWN (6 PCS)', 230, 3),
(837, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'CHILLI GARLIC PRAWN (6 PCS)', 230, 3),
(838, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'PRAWN MANCHURIAN (6 PCS)', 230, 3),
(839, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'SCHEZWAN PRAWN (6 PCS)', 230, 3),
(840, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'LEMON PRAWN (6 PCS)', 230, 3),
(841, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'HUNAN PRAWN (6 PCS)', 250, 3),
(842, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'PRAWN SWEET N SOUR (6 PCS)', 250, 3),
(843, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'PRAWN 65 (6 PCS)', 250, 3),
(844, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'CHILLI LEMON PRAWN (6 PCS)', 250, 3),
(845, 'Chinese', 'Side Dish', 'Non Veg', 'Prawn', 'KUNG PAO PRAWN (6 PCS)', 270, 3),
(846, 'Indian', 'Rice', 'Veg', 'Veg', 'STEAMED RICE', 70, 3),
(847, 'Indian', 'Rice', 'Veg', 'Veg', 'JEERA RICE', 100, 3),
(848, 'Indian', 'Rice', 'Veg', 'Veg', 'VEG PULAO', 120, 3),
(849, 'Indian', 'Rice', 'Veg', 'Veg', 'KASHMIRI PULAO', 140, 3),
(850, 'Indian', 'Biriyani', 'Non Veg', 'Chicken', 'CHICKEN BIRIYANI', 150, 3),
(851, 'Indian', 'Biriyani', 'Non Veg', 'Mutton', 'MUTTON BIRIYANI', 170, 3),
(852, 'Indian', 'Bread', 'Veg', 'Roti', 'RUMALI ROTI', 15, 3),
(853, 'Indian', 'Bread', 'Veg', 'Roti', 'TANDOORI ROTI', 25, 3),
(854, 'Indian', 'Bread', 'Veg', 'Roti', 'BUTTER TANDOORI ROTI', 35, 3),
(855, 'Indian', 'Bread', 'Veg', 'Naan', 'PLAIN NAAN', 30, 3),
(856, 'Indian', 'Bread', 'Veg', 'Naan', 'BUTTER NAAN', 40, 3),
(857, 'Indian', 'Bread', 'Veg', 'Lachha', 'LACHHA PARATHA', 30, 3),
(858, 'Indian', 'Bread', 'Veg', 'Kulcha', 'KULCHA ', 40, 3),
(859, 'Indian', 'Bread', 'Veg', 'Kulcha', 'MASALA KULCHA', 70, 3),
(860, 'Indian', 'Side Dish', 'Veg', 'Dal', 'DAL FRY', 90, 3),
(861, 'Indian', 'Side Dish', 'Veg', 'Dal', 'DAL MAKHANI', 110, 3),
(862, 'Indian', 'Side Dish', 'Veg', 'Aloo', 'ALOO MUTTER', 110, 3),
(863, 'Indian', 'Side Dish', 'Veg', 'Aloo', 'JEERA ALOO', 110, 3),
(864, 'Indian', 'Side Dish', 'Veg', 'Aloo', 'DUM ALOO', 120, 3),
(865, 'Indian', 'Side Dish', 'Veg', 'Dal', 'VEG TADKA ', 110, 3),
(866, 'Indian', 'Side Dish', 'Veg', 'Veg', 'VEG SHAHI KOFTA', 130, 3),
(867, 'Indian', 'Side Dish', 'Veg', 'Veg', 'NAVRATAN KORMA', 130, 3),
(868, 'Indian', 'Side Dish', 'Veg', 'Paneer', 'MUTTER PANEER', 130, 3),
(869, 'Indian', 'Side Dish', 'Veg', 'Paneer', 'PANEER MASALA', 130, 3),
(870, 'Indian', 'Side Dish', 'Veg', 'Paneer', 'PANEER BUTTER MASALA', 140, 3),
(871, 'Indian', 'Side Dish', 'Veg', 'Paneer', 'KADHAI PANEER', 130, 3),
(872, 'Indian', 'Side Dish', 'Veg', 'Paneer', 'HANDI PANEER', 130, 3),
(873, 'Indian', 'Side Dish', 'Veg', 'Paneer', 'PANEER KOFTA', 140, 3),
(874, 'Indian', 'Side Dish', 'Veg', 'Paneer', 'PANEER MALAI KOFTA', 150, 3),
(875, 'Indian', 'Side Dish', 'Non Veg', 'Dal', 'EGG TADKA ', 120, 3),
(876, 'Indian', 'Side Dish', 'Veg', 'Dal', 'PANEER TADKA ', 130, 3),
(877, 'Indian', 'Side Dish', 'Non Veg', 'Dal', 'CHICKEN TADKA ', 130, 3),
(878, 'Indian', 'Side Dish', 'Non Veg', 'Dal', 'MUTTON KEEMA TADKA ', 150, 3),
(879, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN CHAAP', 140, 3),
(880, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN CURRY (4 PCS)', 150, 3),
(881, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN KASSA (4 PCS)', 160, 3),
(882, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN KORMA (4 PCS)', 160, 3),
(883, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN MASALA (4 PCS)', 160, 3),
(884, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN DOPiYAZA (4 PCS)', 160, 3),
(885, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN BHARTA', 170, 3),
(886, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN REZALA (4 PCS)', 180, 3),
(887, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'HANDI CHICKEN (4 PCS)', 190, 3),
(888, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'KADHAI CHICKEN (4 PCS)', 190, 3),
(889, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'TAWA CHICKEN (4 PCS)', 190, 3),
(890, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN BEGUM BAHAR (4 PCS)', 200, 3),
(891, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN TIKKA BUTTER MASALA (6 PCS)', 220, 3),
(892, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN TANGRI BUTTER MASALA (2 PCS)', 220, 3),
(893, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN TANDOORI BUTTER MASALA (2 PCS)', 220, 3),
(894, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN RESHMI BUTTER MASALA (6 PCS)', 220, 3),
(895, 'Indian', 'Side Dish', 'Non Veg', 'Chicken', 'CHICKEN HARIYALI BUTTER MASALA (6 PCS)', 220, 3),
(896, 'Indian', 'Side Dish', 'Non Veg', 'Fish', 'FISH MASALA (4 PCS)', 200, 3),
(897, 'Indian', 'Side Dish', 'Non Veg', 'Fish', 'FISH TIKKA BUTTER MASALA (4 PCS)', 220, 3),
(898, 'Indian', 'Side Dish', 'Non Veg', 'Fish', 'FISH RESHMI BUTTER MASALA (4 PCS)', 250, 3),
(899, 'Indian', 'Side Dish', 'Non Veg', 'Fish', 'FISH BEGUM BAHAR (4 PCS)', 250, 3),
(900, 'Indian', 'Side Dish', 'Non Veg', 'Prawn', 'PRAWN MASALA', 240, 3),
(901, 'Indian', 'Side Dish', 'Non Veg', 'Prawn', 'PRAWN BUTTER MASALA', 240, 3),
(902, 'Indian', 'Side Dish', 'Non Veg', 'Prawn', 'PRAWN MALAI CURRY', 250, 3),
(903, 'Indian', 'Side Dish', 'Non Veg', 'Prawn', 'PRAWN BUTTER MASALA', 230, 3),
(904, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON CURRY (4 PCS)', 190, 3),
(905, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON KASSA (4 PCS)', 190, 3),
(906, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON DOPYAZA (4 PCS)', 190, 3),
(907, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON KORMA (4 PCS)', 190, 3),
(908, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON CHAAP (4 PCS)', 210, 3),
(909, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON MASALA (4 PCS)', 210, 3),
(910, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON KEEMA MASALA', 210, 3),
(911, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON REZALA (4 PCS)', 210, 3),
(912, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'TAWA MUTTON (4 PCS)', 230, 3),
(913, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'HANDI MUTTON (4 PCS)', 230, 3),
(914, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'KADHAI MUTTON (4 PCS)', 230, 3),
(915, 'Indian', 'Side Dish', 'Non Veg', 'Mutton', 'MUTTON BEGUM BAHAR (4 PCS)', 250, 3),
(916, 'Indian', 'Salad', 'Veg', 'Veg', 'GREEN SALAD', 50, 3),
(917, 'Indian', 'Salad', 'Veg', 'Veg', 'ONION SALAD', 50, 3),
(918, 'Chinese', 'Salad', 'Non Veg', 'Chicken', 'CHICKEN SALAD', 100, 3),
(919, 'Beverages', 'Beverages', 'Beverages', 'Water', 'MINERAL WATER', 0, 3),
(920, 'Beverages', 'Beverages', 'Beverages', 'Cold Drinks', 'THUMS UP', 30, 3),
(921, 'Beverages', 'Beverages', 'Beverages', 'Cold Drinks', 'LIMCA', 30, 3),
(922, 'Beverages', 'Beverages', 'Beverages', 'Cold Drinks', 'FANTA', 30, 3),
(923, 'Beverages', 'Beverages', 'Beverages', 'Cold Drinks', 'MASALA COLD DRINKS', 40, 3),
(924, 'Beverages', 'Beverages', 'Beverages', 'Soda', 'FRESH LIME SODA', 35, 3),
(925, 'Beverages', 'Beverages', 'Beverages', 'Soda', 'SWEET LIME SODA', 35, 3),
(926, 'Beverages', 'Beverages', 'Beverages', 'Soda', 'MASALA SODA', 35, 3),
(927, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'STRAWBERRY', 70, 3),
(928, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'VANILLA', 80, 3),
(929, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'TWO IN ONE', 80, 3),
(930, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'CHOCOLATE', 80, 3),
(931, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'BUTTER SCOTCH', 80, 3),
(932, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'MANGO', 80, 3),
(933, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'MANGO MASTANI', 110, 3),
(934, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'DREAMY RAINBOW', 110, 3),
(935, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'CHOCOLATE OVERLOAD', 120, 3),
(936, 'Ice Cream', 'Ice Cream', 'Ice Cream', 'Ice Cream', 'CRUNCHY OREO MAGIC', 130, 3);

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `pur_id` int(11) NOT NULL,
  `vendor_invoice` varchar(50) NOT NULL,
  `vendor_name` varchar(100) NOT NULL,
  `vendor_pan` varchar(20) NOT NULL,
  `vendor_contact` varchar(20) NOT NULL,
  `vendor_address` varchar(100) NOT NULL,
  `date_of_order` date NOT NULL,
  `total_amount` float NOT NULL,
  `discount` float NOT NULL,
  `fk_tax_id` int(11) NOT NULL,
  `fk_company` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`pur_id`, `vendor_invoice`, `vendor_name`, `vendor_pan`, `vendor_contact`, `vendor_address`, `date_of_order`, `total_amount`, `discount`, `fk_tax_id`, `fk_company`) VALUES
(39, 'VEN0001', 'Rajesh Stores', '19ABC3212AAA128', '9087654321', 'Siliguri, Darjeeling.', '2018-04-28', 210, 0, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `sales_customer`
--

CREATE TABLE `sales_customer` (
  `sales_cust_id` int(11) NOT NULL,
  `cust_name` varchar(100) NOT NULL,
  `total_amount` float NOT NULL,
  `dated` date NOT NULL,
  `fk_tax_id` int(11) NOT NULL,
  `discount` float NOT NULL,
  `fk_company` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_customer`
--

INSERT INTO `sales_customer` (`sales_cust_id`, `cust_name`, `total_amount`, `dated`, `fk_tax_id`, `discount`, `fk_company`) VALUES
(4, '334', 31.5, '2018-04-30', 2, 0, 3),
(6, '234', 480, '2018-04-30', 0, 0, 2),
(7, 'wda', 0, '2018-04-30', 0, 0, 2),
(8, '5', 210, '2018-05-01', 0, 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `sales_report`
--

CREATE TABLE `sales_report` (
  `sales_report_id` int(11) NOT NULL,
  `fk_menu_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `rate` float NOT NULL,
  `final_rate` float NOT NULL,
  `fk_customer_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_report`
--

INSERT INTO `sales_report` (`sales_report_id`, `fk_menu_id`, `quantity`, `rate`, `final_rate`, `fk_customer_id`) VALUES
(1, 625, 1, 30, 30, 4),
(2, 2, 4, 45, 180, 6),
(3, 7, 6, 50, 300, 6),
(4, 0, 3, 0, 0, 7),
(5, 1, 7, 30, 210, 8);

-- --------------------------------------------------------

--
-- Table structure for table `stock_report`
--

CREATE TABLE `stock_report` (
  `stock_id` int(11) NOT NULL,
  `fk_inv_id` int(11) NOT NULL,
  `items_received_by` varchar(100) NOT NULL,
  `current_quan` int(11) NOT NULL,
  `unit` varchar(5) NOT NULL,
  `dated` date NOT NULL,
  `fk_company` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock_report`
--

INSERT INTO `stock_report` (`stock_id`, `fk_inv_id`, `items_received_by`, `current_quan`, `unit`, `dated`, `fk_company`) VALUES
(7, 943, 'Kitchen', 30, 'L', '2018-04-30', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tax_master`
--

CREATE TABLE `tax_master` (
  `tax_id` int(11) NOT NULL,
  `tax_type` varchar(10) NOT NULL,
  `tax_amount` float NOT NULL,
  `tax_type2` varchar(10) NOT NULL,
  `tax_amount2` varchar(5) NOT NULL,
  `fk_company` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tax_master`
--

INSERT INTO `tax_master` (`tax_id`, `tax_type`, `tax_amount`, `tax_type2`, `tax_amount2`, `fk_company`) VALUES
(1, 'CGST', 2.5, 'SGST', '2.5', 2),
(2, 'CGST', 2.5, 'SGST', '2.5', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank_details`
--
ALTER TABLE `bank_details`
  ADD PRIMARY KEY (`bank_id`),
  ADD KEY `fk_company` (`fk_company`);

--
-- Indexes for table `company_details`
--
ALTER TABLE `company_details`
  ADD PRIMARY KEY (`company_id`);

--
-- Indexes for table `group_ledger`
--
ALTER TABLE `group_ledger`
  ADD PRIMARY KEY (`gl_id`),
  ADD KEY `fk_company` (`fk_company`);

--
-- Indexes for table `inventory_card`
--
ALTER TABLE `inventory_card`
  ADD PRIMARY KEY (`invt_id`),
  ADD KEY `inventory_card_ibfk_1` (`fk_company`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`invoice_id`),
  ADD KEY `invoice_ibfk_5` (`fk_company`),
  ADD KEY `fk_invt_id` (`fk_invt_id`),
  ADD KEY `invoice_ibfk_7` (`fk_purchase_id`);

--
-- Indexes for table `in_hand`
--
ALTER TABLE `in_hand`
  ADD PRIMARY KEY (`in_hand_id`),
  ADD KEY `fk_inv_id` (`fk_inv_id`),
  ADD KEY `fk_company` (`fk_company`);

--
-- Indexes for table `logo`
--
ALTER TABLE `logo`
  ADD PRIMARY KEY (`logo_id`),
  ADD KEY `fk_company` (`fk_company`);

--
-- Indexes for table `menu_card`
--
ALTER TABLE `menu_card`
  ADD PRIMARY KEY (`menu_id`),
  ADD KEY `fk_company` (`fk_company`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD PRIMARY KEY (`pur_id`),
  ADD KEY `fk_company` (`fk_company`),
  ADD KEY `fk_tax_id` (`fk_tax_id`);

--
-- Indexes for table `sales_customer`
--
ALTER TABLE `sales_customer`
  ADD PRIMARY KEY (`sales_cust_id`),
  ADD KEY `sales_customer_ibfk_1` (`fk_company`),
  ADD KEY `fk_tax_id` (`fk_tax_id`);

--
-- Indexes for table `sales_report`
--
ALTER TABLE `sales_report`
  ADD PRIMARY KEY (`sales_report_id`),
  ADD KEY `fk_menu_id` (`fk_menu_id`),
  ADD KEY `fk_customer_id` (`fk_customer_id`);

--
-- Indexes for table `stock_report`
--
ALTER TABLE `stock_report`
  ADD PRIMARY KEY (`stock_id`),
  ADD KEY `stock_report_ibfk_1` (`fk_inv_id`),
  ADD KEY `fk_company` (`fk_company`);

--
-- Indexes for table `tax_master`
--
ALTER TABLE `tax_master`
  ADD PRIMARY KEY (`tax_id`),
  ADD KEY `fk_company` (`fk_company`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bank_details`
--
ALTER TABLE `bank_details`
  MODIFY `bank_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `company_details`
--
ALTER TABLE `company_details`
  MODIFY `company_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `group_ledger`
--
ALTER TABLE `group_ledger`
  MODIFY `gl_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `inventory_card`
--
ALTER TABLE `inventory_card`
  MODIFY `invt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1569;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `invoice_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `in_hand`
--
ALTER TABLE `in_hand`
  MODIFY `in_hand_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `logo`
--
ALTER TABLE `logo`
  MODIFY `logo_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `menu_card`
--
ALTER TABLE `menu_card`
  MODIFY `menu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=937;

--
-- AUTO_INCREMENT for table `purchase`
--
ALTER TABLE `purchase`
  MODIFY `pur_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `sales_customer`
--
ALTER TABLE `sales_customer`
  MODIFY `sales_cust_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `sales_report`
--
ALTER TABLE `sales_report`
  MODIFY `sales_report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `stock_report`
--
ALTER TABLE `stock_report`
  MODIFY `stock_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tax_master`
--
ALTER TABLE `tax_master`
  MODIFY `tax_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bank_details`
--
ALTER TABLE `bank_details`
  ADD CONSTRAINT `bank_details_ibfk_1` FOREIGN KEY (`fk_company`) REFERENCES `company_details` (`company_id`);

--
-- Constraints for table `group_ledger`
--
ALTER TABLE `group_ledger`
  ADD CONSTRAINT `group_ledger_ibfk_1` FOREIGN KEY (`fk_company`) REFERENCES `company_details` (`company_id`) ON DELETE CASCADE;

--
-- Constraints for table `inventory_card`
--
ALTER TABLE `inventory_card`
  ADD CONSTRAINT `inventory_card_ibfk_1` FOREIGN KEY (`fk_company`) REFERENCES `company_details` (`company_id`) ON DELETE CASCADE;

--
-- Constraints for table `invoice`
--
ALTER TABLE `invoice`
  ADD CONSTRAINT `invoice_ibfk_5` FOREIGN KEY (`fk_company`) REFERENCES `company_details` (`company_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `invoice_ibfk_6` FOREIGN KEY (`fk_invt_id`) REFERENCES `inventory_card` (`invt_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `invoice_ibfk_7` FOREIGN KEY (`fk_purchase_id`) REFERENCES `purchase` (`pur_id`) ON DELETE CASCADE;

--
-- Constraints for table `in_hand`
--
ALTER TABLE `in_hand`
  ADD CONSTRAINT `in_hand_ibfk_1` FOREIGN KEY (`fk_inv_id`) REFERENCES `inventory_card` (`invt_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `in_hand_ibfk_2` FOREIGN KEY (`fk_company`) REFERENCES `company_details` (`company_id`) ON DELETE CASCADE;

--
-- Constraints for table `logo`
--
ALTER TABLE `logo`
  ADD CONSTRAINT `logo_ibfk_1` FOREIGN KEY (`fk_company`) REFERENCES `company_details` (`company_id`);

--
-- Constraints for table `menu_card`
--
ALTER TABLE `menu_card`
  ADD CONSTRAINT `menu_card_ibfk_1` FOREIGN KEY (`fk_company`) REFERENCES `company_details` (`company_id`) ON DELETE CASCADE;

--
-- Constraints for table `purchase`
--
ALTER TABLE `purchase`
  ADD CONSTRAINT `purchase_ibfk_1` FOREIGN KEY (`fk_company`) REFERENCES `company_details` (`company_id`);

--
-- Constraints for table `sales_customer`
--
ALTER TABLE `sales_customer`
  ADD CONSTRAINT `sales_customer_ibfk_1` FOREIGN KEY (`fk_company`) REFERENCES `company_details` (`company_id`) ON DELETE CASCADE;

--
-- Constraints for table `sales_report`
--
ALTER TABLE `sales_report`
  ADD CONSTRAINT `sales_report_ibfk_2` FOREIGN KEY (`fk_customer_id`) REFERENCES `sales_customer` (`sales_cust_id`);

--
-- Constraints for table `stock_report`
--
ALTER TABLE `stock_report`
  ADD CONSTRAINT `stock_report_ibfk_1` FOREIGN KEY (`fk_inv_id`) REFERENCES `inventory_card` (`invt_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `stock_report_ibfk_2` FOREIGN KEY (`fk_company`) REFERENCES `company_details` (`company_id`) ON DELETE CASCADE;

--
-- Constraints for table `tax_master`
--
ALTER TABLE `tax_master`
  ADD CONSTRAINT `tax_master_ibfk_1` FOREIGN KEY (`fk_company`) REFERENCES `company_details` (`company_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
